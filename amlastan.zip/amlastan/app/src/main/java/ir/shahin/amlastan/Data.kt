package ir.shahin.amlastan

import android.content.Context
import android.content.SharedPreferences
import java.util.Collections
import java.util.Random
import kotlin.math.max
import kotlin.math.min

/** ذخیره‌ی پیشرفت بازی روی گوشی */
class Store(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("amlastan", Context.MODE_PRIVATE)

    var coins: Int
        get() = p.getInt("coins", 30)
        set(v) {
            p.edit().putInt("coins", max(0, v)).apply()
        }

    var sfx: Boolean
        get() = p.getBoolean("sfx", true)
        set(v) {
            p.edit().putBoolean("sfx", v).apply()
        }

    var music: Boolean
        get() = p.getBoolean("music", true)
        set(v) {
            p.edit().putBoolean("music", v).apply()
        }

    /** پایه‌ی انتخاب‌شده (۱ تا ۶) */
    var grade: Int
        get() = p.getInt("grade", 1).coerceIn(1, 6)
        set(v) {
            p.edit().putInt("grade", v.coerceIn(1, 6)).apply()
        }

    var totalCorrect: Int
        get() = p.getInt("total_correct", 0)
        set(v) {
            p.edit().putInt("total_correct", v).apply()
        }

    var totalAnswered: Int
        get() = p.getInt("total_answered", 0)
        set(v) {
            p.edit().putInt("total_answered", v).apply()
        }

    fun blitzBest(g: Int): Int = p.getInt("blitz_$g", 0)
    fun setBlitzBest(g: Int, v: Int) {
        p.edit().putInt("blitz_$g", v).apply()
    }

    fun stars(g: Int, i: Int): Int = p.getInt("star_${g}_$i", 0)

    fun setStars(g: Int, i: Int, v: Int) {
        if (v > stars(g, i)) p.edit().putInt("star_${g}_$i", v).apply()
    }

    fun correct(w: String): Int = p.getInt("c_$w", 0)
    fun wrong(w: String): Int = p.getInt("w_$w", 0)

    fun record(w: String, ok: Boolean) {
        val e = p.edit()
        if (ok) e.putInt("c_$w", correct(w) + 1) else e.putInt("w_$w", wrong(w) + 1)
        e.putInt("total_answered", totalAnswered + 1)
        if (ok) e.putInt("total_correct", totalCorrect + 1)
        e.apply()
    }

    fun mastered(w: String): Boolean = correct(w) >= 3 && correct(w) >= 2 * wrong(w)
}

enum class QType { SPELL, MISSING, TF, SCRAMBLE, SENT }

class Question(
    val type: QType,
    /** واژه‌ی درست (برای SENT: واژه‌ی درست جمله) */
    val word: String,
    /** متنی که روی کارت نشان داده می‌شود: واژه‌ی نمایشی (TF)، واژه‌ی ناقص (MISSING) یا جمله‌ی دارای جای خالی (SENT) */
    val shown: String,
    /** برای SENT: جمله‌ی کامل */
    val full: String,
    val options: Array<String>,
    val correctIdx: Int,
    val tfTrue: Boolean,
    val tiles: CharArray,
    val timeLimit: Float
) {
    val disabled = BooleanArray(4)
    var used5050 = false
    val optCount: Int get() = options.size
}

/** تولید سؤال؛ واژه‌هایی که بچه بیشتر اشتباه می‌نویسد بیشتر می‌آیند */
object Gen {
    private val rnd = Random()
    private const val ZW = '‌'
    private const val BLANK = "ـــ"
    private const val COMMON = "بتنردملکیوسافگ"

    private fun weight(store: Store, w: String): Double {
        val c = store.correct(w)
        val x = store.wrong(w)
        if (c + x == 0) return 1.6
        return max(0.25, 1.0 + 2.5 * x - 0.35 * min(c, 5))
    }

    private fun pickIdx(weights: DoubleArray): Int {
        var sum = 0.0
        for (x in weights) sum += x
        var r = rnd.nextDouble() * sum
        for (i in weights.indices) {
            r -= weights[i]
            if (r <= 0.0) return i
        }
        return weights.size - 1
    }

    private fun maxScramble(grade: Int): Int = when (grade) {
        1 -> 4
        2 -> 5
        3 -> 6
        else -> 7
    }

    private fun typeFor(mode: Int, grade: Int, level: Int, idx: Int, finisher: Boolean): QType {
        val sentOk = grade >= 3 && Words.sentences.any { it.minGrade <= grade }
        if (mode == 1) {
            val t = rnd.nextInt(7)
            return when {
                t <= 1 -> QType.SPELL
                t <= 3 -> QType.TF
                t <= 5 -> QType.MISSING
                else -> if (sentOk) QType.SENT else QType.SPELL
            }
        }
        if (mode == 2) {
            return when (rnd.nextInt(5)) {
                0 -> QType.SPELL
                1 -> QType.MISSING
                2 -> QType.TF
                3 -> QType.SCRAMBLE
                else -> if (sentOk) QType.SENT else QType.SPELL
            }
        }
        if (finisher && (grade >= 2 || level >= 2)) return QType.SCRAMBLE
        return when (idx % 6) {
            0 -> QType.SPELL
            1 -> QType.MISSING
            2 -> QType.TF
            3 -> QType.SPELL
            4 -> QType.SCRAMBLE
            else -> if (sentOk && level >= 1) QType.SENT else QType.MISSING
        }
    }

    private fun wrongSpellings(word: String, grade: Int): List<String> {
        val out = ArrayList<String>()
        var tries = 0
        while (out.size < 3 && tries < 40) {
            tries++
            val w = Words.wrongForm(word, grade, rnd, out) ?: break
            out.add(w)
        }
        // اگر حرف هم‌صدا نبود: جابه‌جایی دو حرف کنار هم یا حذف یک حرف
        var k = 0
        while (out.size < 3 && k < 60) {
            k++
            if (word.length < 3) break
            val i = 1 + rnd.nextInt(word.length - 1)
            val sw = if (rnd.nextBoolean()) {
                if (word[i] == ZW || word[i - 1] == ZW) null
                else word.substring(0, i - 1) + word[i] + word[i - 1] + word.substring(i + 1)
            } else {
                if (word[i] == ZW) null else word.substring(0, i) + word.substring(i + 1)
            }
            if (sw != null && sw != word && !out.contains(sw) && !Words.all.contains(sw)) out.add(sw)
        }
        var extra = 0
        while (out.size < 3) {
            extra++
            out.add(word + "ا".repeat(extra))
        }
        return out
    }

    private fun limitFor(type: QType, grade: Int, level: Int, mode: Int): Float {
        if (mode == 1) return 99f
        val base = when (type) {
            QType.SPELL -> 12f
            QType.MISSING -> 12f
            QType.TF -> 8f
            QType.SCRAMBLE -> 22f
            QType.SENT -> 14f
        }
        val lv = if (mode == 2) 4 else level
        var t = max(base * 0.65f, base - lv * 0.4f)
        t *= when (grade) {
            1 -> 1.5f
            2 -> 1.25f
            else -> 1f
        }
        return t
    }

    /**
     * mode: ۰ مرحله، ۱ مسابقه‌ی سریع، ۲ تمرین نقاط ضعف
     * session: شمارنده‌ی پاسخ‌های درست همین دور (برای تنوع)
     */
    fun make(
        mode: Int, grade: Int, level: Int, idx: Int, finisher: Boolean,
        store: Store, session: HashMap<String, Int>, recent: ArrayList<String>
    ): Question {
        val gw = Words.grades[grade - 1]
        var type = typeFor(mode, grade, level, idx, finisher)

        // ---- جمله‌ی هم‌آوا
        if (type == QType.SENT) {
            val list = Words.sentences.filter { it.minGrade <= grade && !recent.contains(it.ok) }
                .ifEmpty { Words.sentences.filter { it.minGrade <= grade } }
            if (list.isEmpty()) {
                type = QType.SPELL
            } else {
                val se = list[rnd.nextInt(list.size)]
                recent.add(se.ok)
                while (recent.size > 4) recent.removeAt(0)
                val opts = arrayOf(se.ok, se.bad)
                if (rnd.nextBoolean()) {
                    val t = opts[0]
                    opts[0] = opts[1]
                    opts[1] = t
                }
                return Question(
                    QType.SENT, se.ok, se.text.replace("___", BLANK), se.text.replace("___", se.ok),
                    opts, opts.indexOf(se.ok), true, CharArray(0), limitFor(type, grade, level, mode)
                )
            }
        }

        // ---- فهرست واژه‌های نامزد
        val words = ArrayList<String>()
        val base = ArrayList<Double>()
        if (mode == 0) {
            val n = (gw.size + 8) / 9
            val lo = min(level * n, gw.size - 1)
            val hi = min(gw.size, lo + n)
            for (i in 0 until hi) {
                words.add(gw[i])
                base.add(if (i >= lo) 1.0 else 0.3)
            }
        } else if (mode == 2) {
            val weak = gw.filter { store.wrong(it) > 0 }
            val src = if (weak.size >= 4) weak else gw
            for (w in src) {
                words.add(w)
                base.add(1.0 + store.wrong(w) * 2.0)
            }
        } else {
            for (w in gw) {
                words.add(w)
                base.add(1.0)
            }
        }
        if (type == QType.SCRAMBLE) {
            val ml = maxScramble(grade)
            val keepW = ArrayList<String>()
            val keepB = ArrayList<Double>()
            for (i in words.indices) {
                if (Words.scrambleOk(words[i], ml)) {
                    keepW.add(words[i])
                    keepB.add(base[i])
                }
            }
            if (keepW.size >= 3) {
                words.clear()
                words.addAll(keepW)
                base.clear()
                base.addAll(keepB)
            } else {
                type = QType.SPELL
            }
        }
        val weights = DoubleArray(words.size)
        for (i in words.indices) {
            val w = words[i]
            var x = weight(store, w) * base[i]
            var k = 0
            val seen = session[w] ?: 0
            while (k < seen) {
                x *= 0.35
                k++
            }
            if (recent.contains(w)) x *= 0.02
            weights[i] = max(x, 0.001)
        }
        val word = words[pickIdx(weights)]
        recent.add(word)
        while (recent.size > 4) recent.removeAt(0)
        val limit = limitFor(type, grade, level, mode)
        val noOpts = arrayOf<String>()

        return when (type) {
            QType.SPELL -> {
                val opts = (wrongSpellings(word, grade).take(3) + word).toMutableList()
                Collections.shuffle(opts, rnd)
                Question(type, word, word, word, opts.toTypedArray(), opts.indexOf(word), true, CharArray(0), limit)
            }
            QType.MISSING -> {
                val pos = ArrayList<Int>()
                for (i in word.indices) if (word[i] != ZW && Words.peers(word[i], grade).isNotEmpty()) pos.add(i)
                if (pos.isEmpty()) for (i in word.indices) if (word[i] != ZW) pos.add(i)
                val at = pos[rnd.nextInt(pos.size)]
                val miss = word[at]
                val cand = ArrayList<Char>()
                val pe = Words.peers(miss, grade).toMutableList()
                pe.shuffle(rnd)
                for (ch in pe) cand.add(ch)
                val com = COMMON.toMutableList()
                com.shuffle(rnd)
                for (ch in com) if (ch != miss && !cand.contains(ch)) cand.add(ch)
                val opts = ArrayList<String>()
                for (ch in cand) {
                    if (opts.size >= 3) break
                    val sub = word.substring(0, at) + ch + word.substring(at + 1)
                    if (Words.all.contains(sub)) continue
                    opts.add(ch.toString())
                }
                for (ch in cand) {
                    if (opts.size >= 3) break
                    if (!opts.contains(ch.toString())) opts.add(ch.toString())
                }
                opts.add(miss.toString())
                Collections.shuffle(opts, rnd)
                val masked = word.substring(0, at) + "ـ" + word.substring(at + 1)
                Question(type, word, masked, word, opts.toTypedArray(), opts.indexOf(miss.toString()), true, CharArray(0), limit)
            }
            QType.TF -> {
                val bad = if (rnd.nextBoolean()) Words.wrongForm(word, grade, rnd, emptyList()) else null
                val shown = bad ?: word
                Question(type, word, shown, word, noOpts, 0, bad == null, CharArray(0), limit)
            }
            QType.SCRAMBLE -> {
                val ch = word.toCharArray()
                var tries = 0
                do {
                    for (i in ch.size - 1 downTo 1) {
                        val j = rnd.nextInt(i + 1)
                        val t = ch[i]
                        ch[i] = ch[j]
                        ch[j] = t
                    }
                    tries++
                } while (String(ch) == word && tries < 30)
                Question(type, word, "", word, noOpts, 0, true, ch, limit)
            }
            else -> Question(QType.SPELL, word, word, word, arrayOf(word), 0, true, CharArray(0), limit)
        }
    }
}
