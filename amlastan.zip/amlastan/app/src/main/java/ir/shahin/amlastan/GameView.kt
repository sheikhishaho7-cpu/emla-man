package ir.shahin.amlastan

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** کل بازی روی یک View کشیده می‌شود: صفحه‌ها، انیمیشن‌ها، لمس و منطق */
class GameView(context: Context, private val store: Store, private val snd: SoundEngine) : View(context) {

    private enum class Screen { HOME, MAP, PLAY, RESULT, BOOK, ABOUT, BALLOON, WSEARCH }

    private class Hit(val id: String, val l: Float, val t: Float, val r: Float, val b: Float)

    private class Part(
        var x: Float, var y: Float, var vx: Float, var vy: Float, var age: Float,
        val life: Float, val color: Int, val size: Float, val kind: Int, var rot: Float, val vr: Float
    )

    private class FText(val text: String, var x: Float, var y: Float, var age: Float, val color: Int, val size: Float)

    // ------------------------------------------------------------ وضعیت کلی
    private var screen = Screen.HOME
    private var W = 0f
    private var H = 0f
    private var s = 1f
    private var tAll = 0f
    private var lastNs = 0L
    private var fade = 0f
    private val rnd = java.util.Random()
    private val hits = ArrayList<Hit>()
    private var pressedId: String? = null
    private val parts = ArrayList<Part>()
    private val ftexts = ArrayList<FText>()

    // ------------------------------------------------------------ وضعیت بازی
    private val maxHp = 10
    private var mode = 0 // ۰ مرحله، ۱ مسابقه‌ی سریع، ۲ تمرین نقاط ضعف
    private var level = 0
    private var hearts = 3
    private var score = 0
    private var combo = 0
    private var bestCombo = 0
    private var correctCount = 0
    private var askedCount = 0
    private var coinsEarned = 0
    private var monsterHp = 10
    private var cur: Question? = null
    private var phase = 0 // ۰ سؤال، ۱ بازخورد، ۲ پایان
    private var qLeft = 0f
    private var qMax = 1f
    private var fbTimer = 0f
    private var blitzLeft = 60f
    private var selected = -1
    private var typed = ""
    private var lastWasCorrect = false
    private var paused = false
    private var hurtT = 0f
    private var attackT = 0f
    private var deadT = 0f
    private var shake = 0f
    private var flashRed = 0f
    private var lastTickSec = -1
    private val session = HashMap<String, Int>()
    private val recent = ArrayList<String>()
    private val built = ArrayList<Int>()
    private val wrongWords = ArrayList<String>()
    private val grade: Int get() = store.grade
    private var endPending = 0
    private var endTimer = 0f

    // نتیجه
    private var resWin = false
    private var resStars = 0
    private var resScore = 0
    private var resCorrect = 0
    private var resCombo = 0
    private var resCoins = 0
    private var resNewBest = false
    private var resBest = 0
    private var resT = 0f
    private var resWrong: List<String> = emptyList()
    private var starsShown = 0

    private var selectedNode = -1

    // بادکنک‌ها
    private class Balloon(
        val id: Int, val word: String, val real: String, val ok: Boolean, var x: Float, var y: Float,
        val vy: Float, val col: Int, val colD: Int, val rx: Float, val ph: Float
    )

    private val balloons = ArrayList<Balloon>()
    private var balId = 0
    private var balSpawn = 0f
    private var balTime = 60f
    private var balElapsed = 0f
    private val balCols = intArrayOf(Pal.RED, Pal.BLUE, Pal.PURPLE, Pal.ORANGE, Pal.TURQ, Pal.GREEN)
    private val balColsD = intArrayOf(Pal.RED_D, Pal.BLUE_D, Pal.PURPLE_D, Pal.ORANGE_D, Pal.TURQ_D, Pal.GREEN_D)

    // واژه‌یاب
    private val wsCols = 7
    private val wsGrid = CharArray(49)
    private val wsColor = IntArray(49)
    private val wsWords = ArrayList<String>()
    private val wsFound = BooleanArray(4)
    private val wsDecoys = ArrayList<String>()
    private var wsStart = -1
    private var wsMistakes = 0
    private var wsDone = false
    private var wsDoneT = 0f
    private var wsReward = 0
    private val wsPalette = intArrayOf(Pal.PURPLE_D, Pal.BLUE_D, Pal.ORANGE_D, Pal.RED_D)

    // تم و نام مرحله‌ها برای هر پایه
    private val mapTheme = intArrayOf(7, 5, 1, 4, 8, 10)
    private val playTheme = intArrayOf(7, 5, 9, 4, 8, 10)
    private val stopNames = arrayOf(
        arrayOf("باغچه‌ی گل", "لانه‌ی پرنده‌ها", "چشمه‌ی روشن", "تپه‌ی سبز", "پل چوبی", "مزرعه‌ی گندم", "درخت بزرگ", "باغ میوه", "قصر گل‌ها"),
        arrayOf("ساحل آرام", "خلیج ماهی", "جزیره‌ی نخل", "غار مروارید", "دماغه‌ی باد", "بندر قایق", "صخره‌ی مرجان", "تنگه‌ی موج", "قلعه‌ی دریایی"),
        arrayOf("شیراز", "اصفهان", "یزد", "تبریز", "کاشان", "رشت", "کرمان", "مشهد", "تخت‌جمشید"),
        arrayOf("دره‌ی برگ", "چشمه‌ی سرخ", "جنگل مه", "کلبه‌ی چوبی", "رودخانه", "بیشه‌ی زرین", "دریاچه‌ی آینه", "قله‌ی جنگل", "درخت هزارساله"),
        arrayOf("دامنه‌ی برفی", "گردنه‌ی باد", "غار یخی", "پناهگاه کوه", "دره‌ی عقاب", "پل معلق", "قله‌ی نقره‌ای", "آبشار یخ", "کاخ ابرها"),
        arrayOf("دروازه‌ی بزرگ", "کتابخانه", "باغ شبانه", "برج ستاره", "تالار آینه", "گنبد فیروزه", "رصدخانه", "تالار تاج", "تخت پادشاه")
    )

    // ------------------------------------------------------------ چیدمان
    private var topPad = 0f
    private var hudCy = 0f
    private var nameCy = 0f
    private var barCy = 0f
    private var monR = 0f
    private var monCy = 0f
    private var timerCy = 0f
    private var cardTop = 0f
    private var cardH = 0f
    private var ansTop = 0f
    private var ansBottom = 0f
    private var powerTop = 0f
    private var powerH = 0f

    // ------------------------------------------------------------ منابع نقاشی
    private val shaders = arrayOfNulls<Shader>(11)
    private val bgPaint = Paint()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dunePath = Path()

    private val skyTop = intArrayOf(
        0xFF0A1442.toInt(), 0xFFFBE6B0.toInt(), 0xFF0B2A5E.toInt(), 0xFF3B1C74.toInt(), 0xFF7A2E0E.toInt(),
        0xFF0E4D64.toInt(), 0xFF5C1A3B.toInt(), 0xFF16324F.toInt(), 0xFF3A0CA3.toInt(), 0xFF6A040F.toInt(),
        0xFF10002B.toInt()
    )
    private val skyBot = intArrayOf(
        0xFF3A2C86.toInt(), 0xFFE7B96A.toInt(), 0xFF1BA39C.toInt(), 0xFFD65DB1.toInt(), 0xFFF2994A.toInt(),
        0xFF4CC9F0.toInt(), 0xFFEF476F.toInt(), 0xFF7BD389.toInt(), 0xFF4895EF.toInt(), 0xFFFF9F1C.toInt(),
        0xFF9D4EDD.toInt()
    )
    private val optCols = intArrayOf(Pal.BLUE, Pal.ORANGE, Pal.PURPLE, Pal.TURQ)
    private val optColsD = intArrayOf(Pal.BLUE_D, Pal.ORANGE_D, Pal.PURPLE_D, Pal.TURQ_D)
    private val goldColors = intArrayOf(Pal.GOLD, Pal.ORANGE, Pal.CREAM)
    private val confettiColors = intArrayOf(Pal.RED, Pal.GOLD, Pal.TURQ, Pal.PURPLE, Pal.GREEN, Pal.BLUE, Pal.ORANGE)
    private val praise = arrayOf("آفرین!", "عالی!", "دمت گرم!", "بی‌نظیر!", "درسته!", "ایول!")

    private val nx = floatArrayOf(0.28f, 0.70f, 0.30f, 0.70f, 0.32f, 0.68f, 0.30f, 0.70f, 0.50f)
    private val ny = floatArrayOf(0.93f, 0.82f, 0.71f, 0.60f, 0.49f, 0.38f, 0.27f, 0.16f, 0.05f)
    private val cityNames = arrayOf("شیراز", "اصفهان", "یزد", "تبریز", "کاشان", "رشت", "کرمان", "مشهد", "تخت‌جمشید")

    private val black = 0xFF000000.toInt()
    private val floatLetters = "ابپتجچدرزسشکگلمنویهقغعفخح"

    // ------------------------------------------------------------ چرخه‌ی حیات
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        for (i in shaders.indices) shaders[i] = null
    }

    fun handleBack(): Boolean {
        when (screen) {
            Screen.HOME -> return false
            Screen.PLAY, Screen.BALLOON -> {
                if (phase != 2) {
                    paused = !paused
                    snd.play("click")
                }
            }
            Screen.RESULT -> go(if (mode == 0) Screen.MAP else Screen.HOME)
            Screen.MAP -> {
                if (selectedNode >= 0) selectedNode = -1 else go(Screen.HOME)
            }
            else -> go(Screen.HOME)
        }
        return true
    }

    fun onPauseGame() {
        if ((screen == Screen.PLAY || screen == Screen.BALLOON) && phase != 2) paused = true
    }

    fun onResumeGame() {
        lastNs = 0L
        invalidate()
    }

    private fun trackFor(sc: Screen): Int = when (sc) {
        Screen.HOME, Screen.RESULT -> 0
        Screen.MAP -> 1
        Screen.PLAY -> if (mode == 1) 8 else 1 + grade
        Screen.BALLOON -> 8
        Screen.WSEARCH -> 1 + grade
        else -> 9
    }

    private fun go(sc: Screen) {
        screen = sc
        snd.setTrack(trackFor(sc))
        fade = 1f
        selectedNode = -1
        pressedId = null
        if (sc == Screen.RESULT) {
            resT = 0f
            starsShown = 0
        }
    }

    // ------------------------------------------------------------ لمس
    private fun hitAt(x: Float, y: Float): String? {
        for (i in hits.indices.reversed()) {
            val h = hits[i]
            if (x >= h.l && x <= h.r && y >= h.t && y <= h.b) return h.id
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> pressedId = hitAt(e.x, e.y)
            MotionEvent.ACTION_MOVE -> {
                if (pressedId != null && hitAt(e.x, e.y) != pressedId) pressedId = null
            }
            MotionEvent.ACTION_UP -> {
                val id = hitAt(e.x, e.y)
                val p = pressedId
                pressedId = null
                if (id != null && id == p) onTap(id)
            }
            MotionEvent.ACTION_CANCEL -> pressedId = null
        }
        return true
    }

    private fun onTap(id: String) {
        if (screen == Screen.PLAY || screen == Screen.BALLOON) {
            playTap(id)
            return
        }
        snd.play("click")
        when (id) {
            "h_adv" -> go(Screen.MAP)
            "h_blitz" -> startRun(1, 0)
            "h_book" -> go(Screen.BOOK)
            "h_balloon" -> startBalloon()
            "h_words" -> startWS()
            "ws_next" -> startWS()
            "ws_home" -> go(Screen.HOME)
            "h_about" -> go(Screen.ABOUT)
            "t_music" -> {
                store.music = !store.music
                snd.musicOn = store.music
            }
            "t_sfx" -> {
                store.sfx = !store.sfx
                snd.sfxOn = store.sfx
            }
            "back" -> handleBack()
            "start" -> {
                val i = selectedNode
                if (i >= 0) startRun(0, i)
            }
            "close_card" -> selectedNode = -1
            "locked" -> snd.play("wrong")
            "r_next" -> startRun(0, level + 1)
            "r_again" -> if (mode == 3) startBalloon() else startRun(mode, level)
            "r_back" -> go(if (mode == 0) Screen.MAP else Screen.HOME)
            "weak" -> startRun(2, 0)
            else -> {
                if (id.startsWith("node")) {
                    selectedNode = id.substring(4).toInt()
                } else if (id.startsWith("wc")) {
                    wsTap(id)
                } else if (id.length == 2 && id[0] == 'g') {
                    store.grade = id[1] - '0'
                }
            }
        }
    }

    private fun playTap(id: String) {
        when (id) {
            "pause" -> {
                if (phase != 2) {
                    paused = true
                    snd.play("click")
                }
                return
            }
            "resume" -> {
                paused = false
                snd.play("click")
                return
            }
            "restart" -> {
                snd.play("click")
                if (mode == 3) startBalloon() else startRun(mode, level)
                return
            }
            "quit" -> {
                snd.play("click")
                paused = false
                go(if (mode == 0) Screen.MAP else Screen.HOME)
                return
            }
        }
        if (paused) return
        if (screen == Screen.BALLOON) {
            balloonTap(id)
            return
        }
        val q = cur ?: return
        if (phase != 0) return
        when {
            id.startsWith("opt") -> {
                val i = id.substring(3).toInt()
                if (i < q.optCount && !q.disabled[i]) {
                    selected = i
                    resolve(i == q.correctIdx, false)
                }
            }
            id == "tf1" || id == "tf0" -> {
                val v = id == "tf1"
                selected = if (v) 1 else 0
                resolve(v == q.tfTrue, false)
            }
            id.startsWith("tile") -> {
                val i = id.substring(4).toInt()
                if (q.type == QType.SCRAMBLE && i < q.tiles.size && !built.contains(i)) {
                    built.add(i)
                    snd.play("click")
                    if (built.size == q.tiles.size) {
                        selected = 1
                        resolve(builtString(q) == q.word, false)
                    }
                }
            }
            id == "del" -> {
                if (built.isNotEmpty()) built.removeAt(built.size - 1)
                snd.play("click")
            }
            id == "pw5050" -> use5050()
            id == "pwtime" -> useTime()
        }
    }

    // ------------------------------------------------------------ منطق بازی
    private fun monIdx(): Int = when (mode) {
        0 -> level
        2 -> 9
        else -> 0
    }

    private fun startRun(m: Int, lv: Int) {
        mode = m
        level = lv
        hearts = 3
        score = 0
        combo = 0
        bestCombo = 0
        correctCount = 0
        askedCount = 0
        coinsEarned = 0
        monsterHp = maxHp
        blitzLeft = 60f
        paused = false
        deadT = 0f
        hurtT = 0f
        attackT = 0f
        shake = 0f
        flashRed = 0f
        endPending = 0
        session.clear()
        recent.clear()
        built.clear()
        wrongWords.clear()
        parts.clear()
        ftexts.clear()
        go(Screen.PLAY)
        nextQuestion()
        snd.play("whoosh")
    }

    private fun nextQuestion() {
        val q = Gen.make(mode, grade, level, askedCount, mode != 1 && monsterHp == 1, store, session, recent)
        cur = q
        askedCount++
        qMax = q.timeLimit
        qLeft = qMax
        phase = 0
        selected = -1
        typed = ""
        built.clear()
        lastTickSec = -1
    }

    private fun resolve(ok: Boolean, timeout: Boolean) {
        val q = cur ?: return
        phase = 1
        lastWasCorrect = ok
        store.record(q.word, ok)
        val cx = W / 2f
        if (ok) {
            combo++
            if (combo > bestCombo) bestCombo = combo
            session[q.word] = (session[q.word] ?: 0) + 1
            correctCount++
            val timeBonus = if (qMax < 90f) (qLeft * 2f).toInt() else 5
            val gain = 10 + timeBonus + max(0, combo - 2) * 5
            score += gain
            val coinGain = if (combo >= 5) 3 else if (combo >= 3) 2 else 1
            store.coins = store.coins + coinGain
            coinsEarned += coinGain
            snd.play("correct")
            snd.play("coin")
            ftexts.add(FText("+${fa(gain)}", cx, cardTop - 10f * s, 0f, Pal.GOLD, 76f * s))
            ftexts.add(FText(praise[rnd.nextInt(praise.size)], cx, monCy, 0f, Pal.GREEN, 82f * s))
            if (combo >= 3) {
                ftexts.add(FText("کومبو ${fa(combo)}", cx, timerCy, 0f, Pal.ORANGE, 64f * s))
            }
            burst(cx, cardTop + cardH * 0.5f, 16, 3, 700f * s, goldColors)
            if (mode != 1) {
                monsterHp -= 1
                hurtT = 1f
                snd.play("hit")
                burst(cx, monCy, 14, 1, 800f * s, confettiColors)
                if (monsterHp <= 0) {
                    phase = 2
                    endPending = 1
                    endTimer = 2.0f
                    deadT = 0f
                    snd.play("boom")
                    burst(cx, monCy, 60, 1, 1200f * s, confettiColors)
                    shake = 1f
                    return
                }
                fbTimer = 0.95f
            } else {
                fbTimer = 0.45f
            }
        } else {
            combo = 0
            if (!wrongWords.contains(q.word)) wrongWords.add(q.word)
            snd.play("wrong")
            shake = 1f
            flashRed = 1f
            vibrate(120)
            ftexts.add(FText(if (timeout) "وقت تمام شد!" else "اشتباه شد!", cx, monCy, 0f, Pal.RED, 78f * s))
            if (mode == 1) {
                blitzLeft = max(0f, blitzLeft - 4f)
                ftexts.add(FText("−${fa(4)} ثانیه", cx, timerCy, 0f, Pal.RED, 56f * s))
                fbTimer = 0.9f
            } else {
                hearts--
                attackT = 1f
                fbTimer = 1.7f
                if (hearts <= 0) {
                    phase = 2
                    endPending = 2
                    endTimer = 1.6f
                }
            }
        }
    }

    private fun use5050() {
        val q = cur ?: return
        if (phase != 0) return
        if (q.type != QType.SPELL && q.type != QType.MISSING) return
        if (q.used5050 || store.coins < 15) return
        store.coins = store.coins - 15
        q.used5050 = true
        val wrongIdx = (0..3).filter { it != q.correctIdx }.shuffled()
        q.disabled[wrongIdx[0]] = true
        q.disabled[wrongIdx[1]] = true
        snd.play("power")
    }

    private fun useTime() {
        if (phase != 0 || store.coins < 10) return
        store.coins = store.coins - 10
        if (mode == 1) {
            blitzLeft += 6f
        } else {
            qLeft += 6f
            qMax = max(qMax, qLeft)
        }
        snd.play("power")
        ftexts.add(FText("+${fa(6)} ثانیه", W / 2f, timerCy, 0f, Pal.TURQ, 56f * s))
    }

    private fun finishRun(win: Boolean) {
        resWin = win
        resScore = score
        resCorrect = correctCount
        resCombo = bestCombo
        resWrong = wrongWords.take(3)
        if (win) {
            resStars = hearts.coerceIn(1, 3)
            val bonus = 10 * resStars
            store.coins = store.coins + bonus
            coinsEarned += bonus
            if (mode == 0) store.setStars(grade, level, resStars)
            snd.play("win")
        } else {
            resStars = 0
            snd.play("lose")
        }
        resCoins = coinsEarned
        go(Screen.RESULT)
    }

    private fun finishBlitz() {
        resWin = true
        resStars = 0
        resScore = score
        resCorrect = correctCount
        resCombo = bestCombo
        resWrong = emptyList()
        val bonus = correctCount / 2
        store.coins = store.coins + bonus
        coinsEarned += bonus
        resCoins = coinsEarned
        resNewBest = score > store.blitzBest(grade)
        if (resNewBest) store.setBlitzBest(grade, score)
        resBest = store.blitzBest(grade)
        snd.play("win")
        go(Screen.RESULT)
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(ms)
            }
        } catch (e: Throwable) {
        }
    }

    // ------------------------------------------------------------ به‌روزرسانی
    private fun burst(x: Float, y: Float, n: Int, kind: Int, speed: Float, colors: IntArray) {
        if (parts.size > 360) return
        for (k in 0 until n) {
            val a = rnd.nextFloat() * 6.2832f
            val v = speed * (0.35f + rnd.nextFloat() * 0.8f)
            parts.add(
                Part(
                    x, y, cos(a) * v, sin(a) * v - speed * 0.3f, 0f,
                    0.8f + rnd.nextFloat() * 0.7f, colors[rnd.nextInt(colors.size)],
                    (10f + rnd.nextFloat() * 16f) * s, kind, rnd.nextFloat() * 360f,
                    (rnd.nextFloat() - 0.5f) * 600f
                )
            )
        }
    }

    private fun update(dt: Float) {
        var i = parts.size - 1
        while (i >= 0) {
            val p = parts[i]
            p.age += dt
            p.vy += (if (p.kind == 2) 350f else 1700f) * s * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rot += p.vr * dt
            if (p.age >= p.life) parts.removeAt(i)
            i--
        }
        i = ftexts.size - 1
        while (i >= 0) {
            val f = ftexts[i]
            f.age += dt
            f.y -= 90f * s * dt
            if (f.age >= 1.2f) ftexts.removeAt(i)
            i--
        }
        hurtT = max(0f, hurtT - dt * 3.2f)
        attackT = max(0f, attackT - dt * 2.2f)
        shake = max(0f, shake - dt * 3f)
        flashRed = max(0f, flashRed - dt * 2.2f)

        if (screen == Screen.PLAY) updatePlay(dt)
        if (screen == Screen.BALLOON) updateBalloon(dt)
        if (screen == Screen.WSEARCH && wsDone) wsDoneT += dt
        if (screen == Screen.RESULT) {
            resT += dt
            if ((mode == 0 || mode == 2) && resWin) {
                while (starsShown < resStars && resT > 0.7f + 0.5f * starsShown) {
                    val sx = W / 2f + (starsShown - 1) * 230f * s
                    starsShown++
                    snd.play("star")
                    burst(sx, H * 0.255f, 12, 1, 700f * s, goldColors)
                }
            }
            if (resWin && rnd.nextFloat() < dt * 14f) {
                parts.add(
                    Part(
                        rnd.nextFloat() * W, -20f * s, (rnd.nextFloat() - 0.5f) * 200f * s,
                        (150f + rnd.nextFloat() * 200f) * s, 0f, 4f,
                        confettiColors[rnd.nextInt(confettiColors.size)], 18f * s, 2,
                        rnd.nextFloat() * 360f, (rnd.nextFloat() - 0.5f) * 500f
                    )
                )
            }
        }
    }

    private fun updatePlay(dt: Float) {
        if (paused) return
        when (phase) {
            0 -> {
                if (mode == 1) {
                    blitzLeft -= dt
                    if (blitzLeft <= 5f && blitzLeft > 0f) {
                        val sec = ceil(blitzLeft).toInt()
                        if (sec != lastTickSec) {
                            lastTickSec = sec
                            snd.play("tick")
                        }
                    }
                    if (blitzLeft <= 0f) {
                        blitzLeft = 0f
                        phase = 2
                        endPending = 3
                        endTimer = 0.9f
                        ftexts.add(FText("تمام شد!", W / 2f, monCy, 0f, Pal.GOLD, 100f * s))
                        snd.play("star")
                    }
                } else {
                    qLeft -= dt
                    if (qLeft <= 3f && qLeft > 0f) {
                        val sec = ceil(qLeft).toInt()
                        if (sec != lastTickSec) {
                            lastTickSec = sec
                            snd.play("tick")
                        }
                    }
                    if (qLeft <= 0f) {
                        qLeft = 0f
                        resolve(false, true)
                    }
                }
            }
            1 -> {
                fbTimer -= dt
                if (fbTimer <= 0f) nextQuestion()
            }
            2 -> {
                endTimer -= dt
                if (endPending == 1) deadT = min(1f, deadT + dt * 0.75f)
                if (endTimer <= 0f) {
                    val e = endPending
                    endPending = 0
                    when (e) {
                        1 -> finishRun(true)
                        2 -> finishRun(false)
                        3 -> finishBlitz()
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ نقاشی کلی
    override fun onDraw(c: Canvas) {
        if (width == 0 || height == 0) {
            postInvalidateOnAnimation()
            return
        }
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNs = now
        tAll += dt
        W = width.toFloat()
        H = height.toFloat()
        s = W / 1080f
        calcLayout()
        hits.clear()
        update(dt)
        when (screen) {
            Screen.HOME -> drawHome(c)
            Screen.MAP -> drawMap(c)
            Screen.PLAY -> drawPlay(c)
            Screen.RESULT -> drawResult(c)
            Screen.BOOK -> drawBook(c)
            Screen.ABOUT -> drawAbout(c)
            Screen.BALLOON -> drawBalloon(c)
            Screen.WSEARCH -> drawWS(c)
        }
        drawFx(c)
        if (flashRed > 0f) c.drawColor(withAlpha(Pal.RED, (flashRed * 90f).toInt()))
        if (fade > 0f) {
            c.drawColor(withAlpha(Pal.NIGHT1, (fade * 255f).toInt()))
            fade = max(0f, fade - dt * 2.8f)
        }
        postInvalidateOnAnimation()
    }

    private fun calcLayout() {
        topPad = 64f * s
        hudCy = topPad + 55f * s
        nameCy = hudCy + 95f * s
        barCy = nameCy + 55f * s
        monR = min(230f * s, H * 0.1f)
        monCy = barCy + 40f * s + monR * 1.5f
        timerCy = monCy + monR + 62f * s
        cardTop = timerCy + 36f * s
        cardH = 230f * s
        ansTop = cardTop + cardH + 44f * s
        powerH = 112f * s
        powerTop = H - 64f * s - powerH
        ansBottom = powerTop - 30f * s
    }

    private fun drawBackground(c: Canvas, theme: Int, scene: Int = -1, hz: Float = 0f) {
        val th = theme.coerceIn(0, 10)
        var sh = shaders[th]
        if (sh == null) {
            sh = LinearGradient(0f, 0f, 0f, H, skyTop[th], skyBot[th], Shader.TileMode.CLAMP)
            shaders[th] = sh
        }
        bgPaint.shader = sh
        c.drawRect(0f, 0f, W, H, bgPaint)

        // الگوی شمسه‌های گره‌چینی که آرام حرکت می‌کنند
        val sp = 280f * s
        val rowH = sp * 0.866f
        val period = rowH * 2f
        val off = (tAll * 14f * s) % period
        val pc = if (th == 1) withAlpha(Pal.BROWN, 38) else withAlpha(Pal.WHITE, 20)
        var y = -period + off
        var row = 0
        while (y < H + sp) {
            var x = -sp + (if (row % 2 == 0) 0f else sp / 2f)
            while (x < W + sp) {
                Draw.girih(c, x, y, 92f * s, 0f, pc, 3f * s)
                x += sp
            }
            y += rowH
            row++
        }
        // ستاره‌های شب
        if (th != 1) {
            for (i in 0 until 34) {
                val sx = ((i * 7919) % 1000) / 1000f * W
                val sy = ((i * 6007) % 1000) / 1000f * H * 0.6f
                val tw = 0.5f + 0.5f * sin(tAll * (1.2f + (i % 5) * 0.4f) + i)
                Draw.circle(c, sx, sy, (2f + (i % 3)) * s, withAlpha(Pal.WHITE, (60 + 150 * tw).toInt()))
            }
        }
        if (scene >= 0) drawScene(c, scene, hz)
        // عددهای شناور
        val dc = withAlpha(if (th == 1) Pal.BROWN else Pal.WHITE, 30)
        for (i in 0 until 12) {
            val speed = (28f + (i % 5) * 11f) * s
            val fx = ((i * 337 + 91) % 1000) / 1000f * W
            val fy = H + 120f * s - ((tAll * speed + i * 211f * s) % (H + 240f * s))
            val sz = (54f + (i % 4) * 22f) * s
            Draw.text(c, floatLetters[i % floatLetters.length].toString(), fx + sin(tAll * 0.6f + i) * 26f * s, fy, sz, dc, 0)
        }
    }

    private fun btn(
        c: Canvas, id: String, l: Float, t: Float, r: Float, b: Float, label: String,
        col: Int, colD: Int, size: Float, enabled: Boolean = true, labelDx: Float = 0f
    ) {
        val pressed = enabled && pressedId == id
        val depth = 14f * s
        val dy = if (pressed) depth * 0.7f else 0f
        val rad = min((b - t) * 0.28f, 40f * s)
        Draw.rect(c, l, t + depth, r, b, rad, colD)
        Draw.rect(c, l, t + dy, r, b - depth + dy, rad, col)
        Draw.rect(c, l + 10f * s, t + dy + 8f * s, r - 10f * s, t + dy + (b - t - depth) * 0.45f, rad * 0.8f, withAlpha(Pal.WHITE, 55))
        if (label.isNotEmpty()) {
            val maxW = (r - l) * 0.9f - abs(labelDx) * 2f
            Draw.text(c, label, (l + r) / 2f + labelDx, (t + b - depth) / 2f + dy, Draw.fit(label, size, maxW), Pal.WHITE)
        }
        if (enabled) hits.add(Hit(id, l, t, r, b))
    }

    private fun chip(c: Canvas, id: String, cx: Float, cy: Float, w: Float, label: String, on: Boolean) {
        val h = 74f * s
        btn(
            c, id, cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f + 14f * s, label,
            if (on) Pal.GREEN else Pal.GRAY, if (on) Pal.GREEN_D else Pal.GRAY_D, 32f * s
        )
    }

    private fun coinPill(c: Canvas, rightX: Float, cy: Float) {
        val w = 250f * s
        val h = 74f * s
        Draw.rect(c, rightX - w, cy - h / 2f, rightX, cy + h / 2f, h / 2f, withAlpha(black, 110))
        Draw.coin(c, rightX - w + 40f * s, cy, 28f * s)
        Draw.text(c, fa(store.coins), (rightX - w + 75f * s + rightX - 15f * s) / 2f, cy, 44f * s, Pal.GOLD)
    }

    private fun backButton(c: Canvas) {
        btn(c, "back", 30f * s, topPad + 8f * s, 270f * s, topPad + 112f * s + 14f * s, "بازگشت", Pal.BLUE, Pal.BLUE_D, 40f * s)
    }

    // ------------------------------------------------------------ صفحه‌ی اصلی
    private fun duneY(x: Float, base: Float, amp: Float, freq: Float, ph: Float): Float =
        base + sin(x / s * freq + ph) * amp * s

    private fun fillDune(c: Canvas, base: Float, amp: Float, freq: Float, ph: Float, color: Int) {
        dunePath.reset()
        dunePath.moveTo(0f, H)
        var x = 0f
        while (x <= W + 40f * s) {
            dunePath.lineTo(x, duneY(x, base, amp, freq, ph))
            x += 36f * s
        }
        dunePath.lineTo(W + 40f * s, H)
        dunePath.close()
        fillPaint.shader = null
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = color
        c.drawPath(dunePath, fillPaint)
    }

    private val gradeNames = arrayOf("اول", "دوم", "سوم", "چهارم", "پنجم", "ششم")

    private fun gradeChips(c: Canvas, cy: Float) {
        val cw = 150f * s
        val cg = 14f * s
        val total = 6f * cw + 5f * cg
        val cx = W / 2f
        for (k in 0..5) {
            val gx = cx + total / 2f - cw / 2f - k * (cw + cg)
            chip(c, "g${k + 1}", gx, cy, cw, gradeNames[k], grade == k + 1)
        }
    }

    private fun drawHome(c: Canvas) {
        drawBackground(c, 0)
        val cx = W / 2f
        // ماه
        Draw.circle(c, W * 0.84f, H * 0.17f, 92f * s, withAlpha(0xFFFFE9A8.toInt(), 40))
        Draw.circle(c, W * 0.84f, H * 0.17f, 66f * s, 0xFFFFE9A8.toInt())
        // عنوان
        Draw.girih(c, cx, H * 0.235f, 470f * s, tAll * 5f, withAlpha(Pal.GOLD, 90), 5f * s)
        Draw.girih(c, cx, H * 0.235f, 370f * s, -tAll * 7f, withAlpha(Pal.TURQ, 90), 4f * s)
        val title = "املای من"
        Draw.text(c, title, cx, H * 0.225f, Draw.fit(title, 200f * s, 840f * s), Pal.GOLD, Pal.ORANGE_D)
        Draw.text(c, "ماجراجویی املای فارسی", cx, H * 0.225f + 150f * s, 56f * s, Pal.CREAM)
        Draw.text(c, "ویژه‌ی دبستان", cx, H * 0.225f + 215f * s, 42f * s, withAlpha(Pal.CREAM, 200), 0)

        // تپه‌های شنی و کاروان
        val b1 = H * 0.43f
        fillDune(c, b1, 38f, 0.004f, 1f, 0xFF2B2468.toInt())
        val camX = (tAll * 55f * s) % (W + 500f * s) - 250f * s
        Art.camel(c, camX, duneY(camX, b1, 38f, 0.004f, 1f) + 8f * s, 0.5f * s, tAll, true, false)
        fillDune(c, H * 0.475f, 44f, 0.0035f, 3f, 0xFF3B2F85.toInt())

        // انتخاب پایه
        Draw.text(c, "پایه‌ات را انتخاب کن", cx, H * 0.512f, 46f * s, Pal.CREAM, 0)
        gradeChips(c, H * 0.558f)

        // دکمه‌ها
        val pulse = 1f + 0.012f * sin(tAll * 3f)
        val bw = 800f * s
        val bh = 120f * s
        val gap = 20f * s
        var y0 = H * 0.615f
        btn(c, "h_adv", cx - bw * pulse / 2f, y0, cx + bw * pulse / 2f, y0 + bh, "ماجراجویی", Pal.GREEN, Pal.GREEN_D, 62f * s)
        y0 += bh + gap
        val hw = (bw - gap) / 2f
        val sh = 104f * s
        val xr = cx + bw / 2f
        btn(c, "h_blitz", xr - hw, y0, xr, y0 + sh, "مسابقه‌ی ${fa(60)} ثانیه", Pal.ORANGE, Pal.ORANGE_D, 44f * s)
        btn(c, "h_balloon", cx - bw / 2f, y0, cx - bw / 2f + hw, y0 + sh, "بادکنک‌ها", Pal.RED, Pal.RED_D, 46f * s)
        y0 += sh + gap
        btn(c, "h_words", xr - hw, y0, xr, y0 + sh, "واژه‌یاب", Pal.BLUE, Pal.BLUE_D, 46f * s)
        btn(c, "h_book", cx - bw / 2f, y0, cx - bw / 2f + hw, y0 + sh, "دفتر غلط‌ها", Pal.PURPLE, Pal.PURPLE_D, 44f * s)
        y0 += sh + gap
        btn(c, "h_about", cx - bw / 2f, y0, cx + bw / 2f, y0 + sh, "طراح و سازنده", Pal.TURQ, Pal.TURQ_D, 50f * s)

        // نوار بالا
        chip(c, "t_music", 30f * s + 130f * s, topPad + 40f * s, 260f * s, "موسیقی", store.music)
        chip(c, "t_sfx", 30f * s + 130f * s + 280f * s, topPad + 40f * s, 260f * s, "جلوه‌ها", store.sfx)
        coinPill(c, W - 30f * s, topPad + 40f * s)

        Draw.text(c, "طراح و سازنده: شاهین شیخ کانلو", cx, H - 56f * s, 38f * s, withAlpha(Pal.CREAM, 200), 0)
    }

    // ------------------------------------------------------------ نقشه‌ی سفر
    private fun nodeX(i: Int): Float = W * nx[i]
    private fun nodeY(i: Int): Float = H * (0.19f + 0.70f * ny[i])
    private fun unlocked(i: Int): Boolean = i == 0 || store.stars(grade, i - 1) >= 1
    private fun currentNode(): Int {
        for (i in 0..8) if (store.stars(grade, i) == 0) return i
        return 8
    }

    private fun drawMap(c: Canvas) {
        val light = mapTheme[grade - 1] == 1
        val tc = if (light) Pal.BROWN else Pal.CREAM
        val nc = if (light) Pal.INK else Pal.WHITE
        val nsh = if (light) 0x44FFFFFF else 0x66000000
        drawBackground(c, mapTheme[grade - 1], grade - 1, H * 0.80f)
        Draw.text(c, "پایه‌ی ${gradeNames[grade - 1]}", W / 2f, topPad + 60f * s, Draw.fit("پایه‌ی ${gradeNames[grade - 1]}", 76f * s, 480f * s), tc, nsh)
        backButton(c)
        coinPill(c, W - 30f * s, topPad + 60f * s)

        // مسیر نقطه‌چین بین شهرها
        for (i in 0 until 8) {
            val x0 = nodeX(i)
            val y0 = nodeY(i)
            val x1 = nodeX(i + 1)
            val y1 = nodeY(i + 1)
            val ym = (y0 + y1) / 2f
            val open = unlocked(i + 1)
            for (k in 1..13) {
                val t = k / 14f
                val u = 1f - t
                val px = u * u * u * x0 + 3f * u * u * t * x0 + 3f * u * t * t * x1 + t * t * t * x1
                val py = u * u * u * y0 + 3f * u * u * t * ym + 3f * u * t * t * ym + t * t * t * y1
                Draw.circle(c, px, py, (if (open) 9f else 7f) * s, if (open) Pal.GOLD_D else withAlpha(Pal.BROWN, 140))
            }
        }

        val curN = currentNode()
        for (i in 0..8) {
            val x = nodeX(i)
            val y = nodeY(i)
            val open = unlocked(i)
            val r = (if (i == 8) 86f else 72f) * s
            if (i == curN) {
                Draw.ring(c, x, y, r + 14f * s + sin(tAll * 4f) * 8f * s, withAlpha(Pal.GOLD_D, 220), 8f * s)
            }
            Draw.circle(c, x, y + 8f * s, r, withAlpha(black, 50))
            Draw.circle(c, x, y, r, if (open) Pal.TURQ_D else Pal.GRAY_D)
            Draw.circle(c, x, y, r - 8f * s, if (open) Pal.TURQ else Pal.GRAY)
            Draw.ring(c, x, y, r, if (open) Pal.GOLD else Pal.GRAY_D, 7f * s)
            if (open) Draw.dome(c, x, y + r * 0.35f, r, Pal.CREAM, Pal.GOLD_D) else Draw.lock(c, x, y - r * 0.1f, r * 0.9f, Pal.CREAM)
            val st = store.stars(grade, i)
            for (k in 0..2) {
                Draw.star(
                    c, x + (k - 1) * r * 0.62f, y - r - 26f * s + (if (k == 1) -10f * s else 0f),
                    20f * s, 9f * s, 5, 0f, if (k < st) Pal.GOLD else withAlpha(Pal.BROWN, 90)
                )
            }
            val nm = stopNames[grade - 1][i]
            Draw.text(c, nm, x, y + r + 40f * s, Draw.fit(nm, 42f * s, 300f * s), nc, nsh)
            hits.add(Hit(if (open) "node$i" else "locked", x - r, y - r - 44f * s, x + r, y + r + 70f * s))
        }

        // شتر کاروان کنار شهر فعلی
        val nodeRight = nx[curN] > 0.5f
        val camX = nodeX(curN) + (if (nodeRight) -200f else 200f) * s
        Art.camel(c, camX, nodeY(curN) + 70f * s, 0.36f * s, tAll, true, !nodeRight)

        if (selectedNode >= 0) drawNodeCard(c)
    }

    private fun drawNodeCard(c: Canvas) {
        hits.clear()
        c.drawColor(withAlpha(black, 150))
        val i = selectedNode
        val l = 80f * s
        val r = W - 80f * s
        val t = H * 0.5f - 480f * s
        val b = H * 0.5f + 480f * s
        Draw.rect(c, l, t + 14f * s, r, b + 14f * s, 50f * s, withAlpha(black, 80))
        Draw.rect(c, l, t, r, b, 50f * s, Pal.CREAM)
        Draw.frame(c, l + 14f * s, t + 14f * s, r - 14f * s, b - 14f * s, 40f * s, Pal.GOLD, 8f * s)
        Draw.text(c, stopNames[grade - 1][i], W / 2f, t + 100f * s, Draw.fit(stopNames[grade - 1][i], 84f * s, W - 300f * s), Pal.INK, 0x22000000)
        val sub = if (i < 8) "مرحله‌ی ${fa(i + 1)}" else "مرحله‌ی آخر"
        Draw.text(c, sub, W / 2f, t + 185f * s, 54f * s, Pal.TURQ_D, 0)
        Art.monster(c, W / 2f, t + 420f * s, 120f * s, i, tAll, 0f, 0f, 0f)
        Draw.text(c, Art.monsterNames[i], W / 2f, t + 600f * s, 52f * s, Pal.RED_D, 0)
        val st = store.stars(grade, i)
        for (k in 0..2) {
            Draw.star(
                c, W / 2f + (k - 1) * 110f * s, t + 668f * s + (if (k == 1) -12f * s else 0f),
                44f * s, 20f * s, 5, 0f, if (k < st) Pal.GOLD else withAlpha(Pal.BROWN, 90)
            )
        }
        btn(c, "start", l + 70f * s, b - 240f * s, r - 70f * s, b - 90f * s, "شروع ماجراجویی", Pal.GREEN, Pal.GREEN_D, 56f * s)
        btn(c, "close_card", r - 150f * s, t + 30f * s, r - 40f * s, t + 140f * s, "", Pal.RED, Pal.RED_D, 10f)
        val xc = r - 95f * s
        val xy = t + 70f * s
        Draw.line(c, xc - 18f * s, xy - 18f * s, xc + 18f * s, xy + 18f * s, Pal.WHITE, 10f * s)
        Draw.line(c, xc - 18f * s, xy + 18f * s, xc + 18f * s, xy - 18f * s, Pal.WHITE, 10f * s)
    }

    // ------------------------------------------------------------ بازی
    private fun drawEq(c: Canvas, tokens: Array<String>, colors: IntArray, cx: Float, cy: Float, size: Float) {
        val gap = size * 0.28f
        var total = 0f
        for (tk in tokens) total += Draw.textWidth(tk, size)
        total += gap * (tokens.size - 1)
        var x = cx - total / 2f
        for (i in tokens.indices) {
            val w = Draw.textWidth(tokens[i], size)
            Draw.text(c, tokens[i], x + w / 2f, cy, size, colors[i], 0x33000000)
            x += w + gap
        }
    }

    private fun drawPlay(c: Canvas) {
        val q = cur ?: return
        drawBackground(c, playTheme[grade - 1], grade - 1, monCy + monR * 0.95f)
        c.save()
        if (shake > 0f) c.translate((rnd.nextFloat() - 0.5f) * shake * 30f * s, (rnd.nextFloat() - 0.5f) * shake * 30f * s)
        val cx = W / 2f

        // نوار بالا
        btn(c, "pause", 30f * s, hudCy - 52f * s, 134f * s, hudCy + 52f * s + 14f * s, "", Pal.BLUE, Pal.BLUE_D, 10f)
        Draw.rect(c, 82f * s - 17f * s, hudCy - 22f * s, 82f * s - 5f * s, hudCy + 22f * s, 4f * s, Pal.WHITE)
        Draw.rect(c, 82f * s + 5f * s, hudCy - 22f * s, 82f * s + 17f * s, hudCy + 22f * s, 4f * s, Pal.WHITE)
        Draw.rect(c, cx - 190f * s, hudCy - 42f * s, cx + 190f * s, hudCy + 42f * s, 42f * s, withAlpha(black, 110))
        Draw.text(c, "امتیاز: ${fa(score)}", cx, hudCy, 46f * s, Pal.CREAM)
        if (mode != 1) {
            for (i in 0..2) {
                Draw.heart(c, W - 70f * s - i * 100f * s, hudCy, 86f * s, if (i < hearts) Pal.RED else withAlpha(Pal.WHITE, 60))
            }
        } else if (combo >= 2) {
            Draw.text(c, "کومبو ${fa(combo)}", W - 200f * s, hudCy, 46f * s, Pal.ORANGE)
        }
        val name = when (mode) {
            0 -> Art.monsterNames[level]
            2 -> "تمرین نقاط ضعف"
            else -> "مسابقه‌ی ${fa(60)} ثانیه"
        }
        Draw.text(c, name, cx, nameCy, 46f * s, Pal.CREAM)

        // جان دیو یا ساعت
        if (mode != 1) {
            val bw = 740f * s
            val bh = 36f * s
            Draw.rect(c, cx - bw / 2f, barCy - bh / 2f, cx + bw / 2f, barCy + bh / 2f, bh / 2f, withAlpha(black, 110))
            val frac = (monsterHp / maxHp.toFloat()).coerceIn(0f, 1f)
            if (frac > 0f) {
                Draw.rect(
                    c, cx - bw / 2f + 4f * s, barCy - bh / 2f + 4f * s,
                    cx - bw / 2f + 4f * s + (bw - 8f * s) * frac, barCy + bh / 2f - 4f * s, bh / 2f,
                    if (frac > 0.5f) Pal.GREEN else if (frac > 0.25f) Pal.GOLD else Pal.RED
                )
            }
        }
        if (mode == 1) {
            val rr = monR * 0.8f
            Draw.circle(c, cx, monCy, rr + 24f * s, withAlpha(black, 70))
            Draw.ring(c, cx, monCy, rr, withAlpha(Pal.WHITE, 70), 26f * s)
            val frac = (blitzLeft / 60f).coerceIn(0f, 1f)
            Draw.arc(c, cx, monCy, rr, -90f, 360f * frac, if (blitzLeft <= 10f) Pal.RED else Pal.GOLD, 26f * s)
            Draw.text(c, fa(ceil(blitzLeft).toInt()), cx, monCy, rr * 0.95f, Pal.WHITE)
        } else if (deadT < 1f) {
            Art.monster(c, cx, monCy, monR, monIdx(), tAll, hurtT.coerceIn(0f, 1f), attackT.coerceIn(0f, 1f), deadT)
        }

        // نوار زمان سؤال
        if (mode != 1) {
            val tw = 820f * s
            val th = 26f * s
            Draw.rect(c, cx - tw / 2f, timerCy - th / 2f, cx + tw / 2f, timerCy + th / 2f, th / 2f, withAlpha(black, 110))
            val frac = (qLeft / qMax).coerceIn(0f, 1f)
            if (frac > 0f) {
                Draw.rect(
                    c, cx - tw / 2f + 4f * s, timerCy - th / 2f + 4f * s,
                    cx - tw / 2f + 4f * s + (tw - 8f * s) * frac, timerCy + th / 2f - 4f * s, th / 2f,
                    if (frac > 0.5f) Pal.TURQ else if (frac > 0.25f) Pal.GOLD else Pal.RED
                )
            }
        }

        // کارت سؤال
        val cl = 70f * s
        val cr = W - 70f * s
        val border = if (phase == 0) Pal.GOLD else if (lastWasCorrect) Pal.GREEN else Pal.RED
        Draw.rect(c, cl, cardTop + 14f * s, cr, cardTop + cardH + 14f * s, 44f * s, withAlpha(black, 70))
        Draw.rect(c, cl, cardTop, cr, cardTop + cardH, 44f * s, Pal.CREAM)
        Draw.frame(c, cl + 10f * s, cardTop + 10f * s, cr - 10f * s, cardTop + cardH - 10f * s, 36f * s, border, 7f * s)
        Draw.girih(c, cl + 52f * s, cardTop + 52f * s, 26f * s, tAll * 20f, Pal.GOLD_D, 3f * s)
        Draw.girih(c, cr - 52f * s, cardTop + 52f * s, 26f * s, -tAll * 20f, Pal.GOLD_D, 3f * s)
        Draw.girih(c, cl + 52f * s, cardTop + cardH - 52f * s, 26f * s, -tAll * 20f, Pal.GOLD_D, 3f * s)
        Draw.girih(c, cr - 52f * s, cardTop + cardH - 52f * s, 26f * s, tAll * 20f, Pal.GOLD_D, 3f * s)

        val reveal = phase != 0
        val ink = Pal.INK
        val good = Pal.GREEN_D
        val promptCol = Pal.PURPLE_D
        val hintCol = Pal.GRAY_D
        val maxW = cr - cl - 130f * s
        val midY = cardTop + cardH * 0.58f
        when (q.type) {
            QType.SPELL -> {
                if (!reveal) {
                    val msg = "کدام درست نوشته شده؟"
                    Draw.text(c, msg, cx, cardTop + cardH * 0.5f, Draw.fit(msg, 78f * s, maxW), promptCol, 0)
                } else {
                    Draw.text(c, "نوشتن درست واژه", cx, cardTop + 66f * s, 40f * s, hintCol, 0)
                    Draw.text(c, q.word, cx, midY + 10f * s, Draw.fit(q.word, 120f * s, maxW), good, 0x33000000)
                }
            }
            QType.MISSING -> {
                Draw.text(c, "حرف گم‌شده را پیدا کن", cx, cardTop + 66f * s, 40f * s, hintCol, 0)
                val tx = if (reveal) q.word else q.shown
                Draw.text(c, tx, cx, midY + 10f * s, Draw.fit(tx, 124f * s, maxW), if (reveal) good else ink, 0x33000000)
            }
            QType.TF -> {
                Draw.text(c, "آیا این واژه درست نوشته شده؟", cx, cardTop + 66f * s, Draw.fit("آیا این واژه درست نوشته شده؟", 40f * s, maxW), hintCol, 0)
                if (reveal && !q.tfTrue) {
                    Draw.text(c, q.shown, cx, cardTop + 120f * s, Draw.fit(q.shown, 84f * s, maxW), Pal.RED_D, 0x33000000)
                    Draw.text(c, q.word, cx, cardTop + 188f * s, Draw.fit(q.word, 70f * s, maxW), good, 0x33000000)
                } else {
                    Draw.text(c, q.shown, cx, midY + 10f * s, Draw.fit(q.shown, 124f * s, maxW), if (reveal) good else ink, 0x33000000)
                }
            }
            QType.SCRAMBLE -> {
                Draw.text(c, "حرف‌ها را مرتب کن", cx, cardTop + 66f * s, 40f * s, hintCol, 0)
                if (reveal) {
                    Draw.text(c, q.word, cx, midY + 10f * s, Draw.fit(q.word, 124f * s, maxW), if (lastWasCorrect) good else Pal.RED_D, 0x33000000)
                    if (!lastWasCorrect) {
                        Draw.text(c, "درست: ${q.word}", cx, cardTop + cardH - 40f * s, 44f * s, good, 0)
                    }
                } else {
                    val b = builtString(q)
                    if (b.isNotEmpty()) {
                        Draw.text(c, b, cx, midY + 4f * s, Draw.fit(b, 124f * s, maxW), ink, 0x33000000)
                    }
                    val left = q.tiles.size - built.size
                    Draw.text(c, "${fa(left)} حرف مانده", cx, cardTop + cardH - 40f * s, 38f * s, hintCol, 0)
                }
            }
            QType.SENT -> {
                Draw.text(c, "جای خالی را درست پر کن", cx, cardTop + 62f * s, 38f * s, hintCol, 0)
                val tx = if (reveal) q.full else q.shown
                Draw.text(c, tx, cx, cardTop + cardH * 0.62f, Draw.fit(tx, 70f * s, maxW), if (reveal) good else ink, 0x33000000)
            }
        }

        // پاسخ‌ها
        when (q.type) {
            QType.SPELL, QType.MISSING, QType.SENT -> drawChoices(c, q)
            QType.TF -> drawTrueFalse(c, q)
            QType.SCRAMBLE -> drawTiles(c, q)
        }

        // کمک‌ها
        val can5050 = phase == 0 && (q.type == QType.SPELL || q.type == QType.MISSING) && !q.used5050 && store.coins >= 15
        val canTime = phase == 0 && store.coins >= 10
        val pl = 80f * s
        val pr = W - 80f * s
        val pm = W / 2f
        val pcy = (powerTop + powerTop + powerH - 14f * s) / 2f
        btn(
            c, "pw5050", pl, powerTop, pm - 12f * s, powerTop + powerH, "حذف دو گزینه",
            if (can5050) Pal.PURPLE else Pal.GRAY, if (can5050) Pal.PURPLE_D else Pal.GRAY_D, 38f * s, can5050, 50f * s
        )
        Draw.coin(c, pm - 12f * s - 52f * s, pcy, 24f * s)
        Draw.text(c, fa(15), pm - 12f * s - 100f * s, pcy, 38f * s, Pal.WHITE, 0)
        btn(
            c, "pwtime", pm + 12f * s, powerTop, pr, powerTop + powerH, "+${fa(6)} ثانیه",
            if (canTime) Pal.TURQ else Pal.GRAY, if (canTime) Pal.TURQ_D else Pal.GRAY_D, 38f * s, canTime, 50f * s
        )
        Draw.coin(c, pr - 52f * s, pcy, 24f * s)
        Draw.text(c, fa(10), pr - 100f * s, pcy, 38f * s, Pal.WHITE, 0)

        c.restore()
        if (paused) drawPause(c)
    }

    private fun drawChoices(c: Canvas, q: Question) {
        val gap = 28f * s
        val n = q.optCount
        val full = n == 2
        val tw = if (full) W - 160f * s else (W - 2f * 80f * s - gap) / 2f
        val th = min(if (full) 230f * s else 210f * s, (ansBottom - ansTop - gap) / 2f)
        for (i in 0 until n) {
            val col = if (full) 0 else i % 2
            val row = if (full) i else i / 2
            val l = 80f * s + col * (tw + gap)
            val t = ansTop + row * (th + gap)
            var fc = optCols[i]
            var fd = optColsD[i]
            if (q.disabled[i] && phase == 0) {
                fc = Pal.GRAY
                fd = Pal.GRAY_D
            }
            if (phase != 0) {
                if (i == q.correctIdx) {
                    fc = Pal.GREEN
                    fd = Pal.GREEN_D
                } else if (i == selected) {
                    fc = Pal.RED
                    fd = Pal.RED_D
                } else {
                    fc = Pal.GRAY
                    fd = Pal.GRAY_D
                }
            }
            val size = if (q.type == QType.MISSING) 120f * s else 84f * s
            btn(c, "opt$i", l, t, l + tw, t + th, q.options[i], fc, fd, size, phase == 0 && !q.disabled[i])
        }
    }

    private fun drawTrueFalse(c: Canvas, q: Question) {
        val gap = 28f * s
        val tw = (W - 2f * 80f * s - gap) / 2f
        val th = min(340f * s, ansBottom - ansTop)
        for (k in 0..1) {
            val yes = k == 1
            val l = 80f * s + (if (yes) tw + gap else 0f)
            var fc = if (yes) Pal.GREEN else Pal.RED
            var fd = if (yes) Pal.GREEN_D else Pal.RED_D
            if (phase != 0) {
                val isCorrectSide = yes == q.tfTrue
                val chosen = (selected == 1) == yes && selected >= 0
                if (isCorrectSide) {
                    fc = Pal.GREEN
                    fd = Pal.GREEN_D
                } else if (chosen) {
                    fc = Pal.RED
                    fd = Pal.RED_D
                } else {
                    fc = Pal.GRAY
                    fd = Pal.GRAY_D
                }
            }
            btn(c, if (yes) "tf1" else "tf0", l, ansTop, l + tw, ansTop + th, "", fc, fd, 10f, phase == 0)
            val icx = l + tw / 2f
            val icy = ansTop + (th - 14f * s) * 0.36f
            val z = 52f * s
            if (yes) {
                Draw.line(c, icx - z, icy, icx - z * 0.3f, icy + z * 0.75f, Pal.WHITE, 22f * s)
                Draw.line(c, icx - z * 0.3f, icy + z * 0.75f, icx + z, icy - z * 0.7f, Pal.WHITE, 22f * s)
            } else {
                Draw.line(c, icx - z * 0.8f, icy - z * 0.8f, icx + z * 0.8f, icy + z * 0.8f, Pal.WHITE, 22f * s)
                Draw.line(c, icx - z * 0.8f, icy + z * 0.8f, icx + z * 0.8f, icy - z * 0.8f, Pal.WHITE, 22f * s)
            }
            Draw.text(c, if (yes) "درسته" else "غلطه", icx, ansTop + (th - 14f * s) * 0.76f, 74f * s, Pal.WHITE)
        }
    }

    private fun builtString(q: Question): String {
        val sb = StringBuilder()
        for (i in built) if (i >= 0 && i < q.tiles.size) sb.append(q.tiles[i])
        return sb.toString()
    }

    private fun drawTiles(c: Canvas, q: Question) {
        val n = q.tiles.size
        val gap = 12f * s
        val areaW = W - 160f * s
        val tw = min(130f * s, (areaW - gap * (n - 1)) / n)
        val th = min(160f * s, tw * 1.25f)
        val total = tw * n + gap * (n - 1)
        val right = W / 2f + total / 2f
        val tileTop = ansTop + 24f * s
        for (i in 0 until n) {
            val r = right - i * (tw + gap)
            val l = r - tw
            val used = built.contains(i)
            if (used) {
                Draw.rect(c, l, tileTop + 14f * s, r, tileTop + th, 22f * s, withAlpha(Pal.WHITE, 40))
            } else {
                val en = phase == 0
                btn(
                    c, "tile$i", l, tileTop, r, tileTop + th, q.tiles[i].toString(),
                    if (en) optCols[i % 4] else Pal.GRAY, if (en) optColsD[i % 4] else Pal.GRAY_D, 90f * s, en
                )
            }
        }
        val dw = 560f * s
        val dh = 120f * s
        val dTop = min(tileTop + th + 70f * s, ansBottom - dh)
        val en = phase == 0 && built.isNotEmpty()
        btn(
            c, "del", W / 2f - dw / 2f, dTop, W / 2f + dw / 2f, dTop + dh, "پاک‌کردن حرف",
            if (en) Pal.ORANGE else Pal.GRAY, if (en) Pal.ORANGE_D else Pal.GRAY_D, 52f * s, en
        )
    }

    private fun drawPause(c: Canvas) {
        hits.clear()
        c.drawColor(withAlpha(black, 170))
        val cx = W / 2f
        Draw.text(c, "توقف", cx, H * 0.27f, 130f * s, Pal.GOLD)
        val bw = 760f * s
        val bh = 140f * s
        var y = H * 0.38f
        btn(c, "resume", cx - bw / 2f, y, cx + bw / 2f, y + bh, "ادامه", Pal.GREEN, Pal.GREEN_D, 64f * s)
        y += bh + 36f * s
        btn(c, "restart", cx - bw / 2f, y, cx + bw / 2f, y + bh, "شروع دوباره", Pal.ORANGE, Pal.ORANGE_D, 58f * s)
        y += bh + 36f * s
        btn(c, "quit", cx - bw / 2f, y, cx + bw / 2f, y + bh, "خروج", Pal.RED, Pal.RED_D, 58f * s)
    }

    // ------------------------------------------------------------ نتیجه
    private fun drawResult(c: Canvas) {
        val th = if (mode == 0) 2 + level else if (mode == 2) 5 else 9
        drawBackground(c, if (resWin) th else 0)
        val cx = W / 2f
        val timed = mode == 1 || mode == 3
        val title = if (timed) "پایان مسابقه!" else if (resWin) "پیروز شدی!" else "دوباره تلاش کن!"
        Draw.girih(c, cx, H * 0.255f, 400f * s, tAll * 8f, withAlpha(Pal.GOLD, 70), 5f * s)
        Draw.text(c, title, cx, H * 0.135f, Draw.fit(title, 120f * s, 900f * s), if (resWin) Pal.GOLD else Pal.CREAM)

        if (timed) {
            Draw.circle(c, cx, H * 0.26f, 190f * s, Pal.GOLD_D)
            Draw.circle(c, cx, H * 0.26f, 170f * s, Pal.GOLD)
            Draw.text(c, fa(resScore), cx, H * 0.26f - 20f * s, Draw.fit(fa(resScore), 130f * s, 280f * s), Pal.INK, 0)
            Draw.text(c, "امتیاز", cx, H * 0.26f + 85f * s, 46f * s, Pal.BROWN, 0)
        } else if (resWin) {
            for (i in 0..2) {
                val sx = cx + (i - 1) * 230f * s
                val sy = H * 0.255f + (if (i == 1) -30f * s else 0f)
                val tt = resT - (0.7f + 0.5f * i)
                if (i < resStars && tt >= 0f) {
                    val sc = min(1f, tt / 0.2f) * (1f + 0.35f * max(0f, 1f - tt / 0.35f))
                    Draw.star(c, sx, sy + 8f * s, 110f * s * sc, 50f * s * sc, 5, 0f, Pal.GOLD_D)
                    Draw.star(c, sx, sy, 110f * s * sc, 50f * s * sc, 5, 0f, Pal.GOLD)
                } else {
                    Draw.star(c, sx, sy, 110f * s, 50f * s, 5, 0f, withAlpha(Pal.WHITE, 60))
                }
            }
        } else {
            Art.monster(c, cx, H * 0.27f, 150f * s, monIdx(), tAll, 0f, 0.5f, 0f)
        }

        val cl = 90f * s
        val cr = W - 90f * s
        val ct = H * 0.40f
        val rowH = 112f * s
        val rows = 4
        val cb = ct + rowH * rows + 40f * s
        Draw.rect(c, cl, ct + 12f * s, cr, cb + 12f * s, 44f * s, withAlpha(black, 70))
        Draw.rect(c, cl, ct, cr, cb, 44f * s, Pal.CREAM)
        Draw.frame(c, cl + 10f * s, ct + 10f * s, cr - 10f * s, cb - 10f * s, 36f * s, Pal.GOLD, 7f * s)
        val labels: Array<String>
        val values: Array<String>
        if (timed) {
            labels = arrayOf(if (mode == 3) "بادکنک ترکانده" else "پاسخ درست", "بیشترین کومبو", "سکه‌ی جایزه", "رکورد")
            values = arrayOf(fa(resCorrect), fa(resCombo), fa(resCoins), fa(resBest))
        } else {
            labels = arrayOf("امتیاز", "پاسخ درست", "بیشترین کومبو", "سکه‌ی جایزه")
            values = arrayOf(fa(resScore), fa(resCorrect), fa(resCombo), fa(resCoins))
        }
        for (i in 0 until rows) {
            val y = ct + 20f * s + rowH * (i + 0.5f)
            Draw.text(c, labels[i], cr - 56f * s, y, 52f * s, Pal.INK, 0, Paint.Align.RIGHT)
            Draw.text(c, values[i], cl + 56f * s, y, 58f * s, Pal.TURQ_D, 0, Paint.Align.LEFT)
        }
        if (timed && resNewBest && resScore > 0) {
            Draw.text(c, "رکورد جدید!", cx, cb + 70f * s, 68f * s + sin(tAll * 8f) * 4f * s, Pal.GOLD)
        } else if (resWrong.isNotEmpty()) {
            val msg = "برای مرور: " + resWrong.joinToString("، ")
            Draw.text(c, msg, cx, cb + 66f * s, Draw.fit(msg, 48f * s, W - 160f * s), Pal.CREAM, 0)
        }

        val bw = 760f * s
        val bh = 130f * s
        var y = cb + 130f * s
        if (resWin && mode == 0 && level < 8) {
            btn(c, "r_next", cx - bw / 2f, y, cx + bw / 2f, y + bh, "مرحله‌ی بعد", Pal.GREEN, Pal.GREEN_D, 58f * s)
            y += bh + 26f * s
        }
        btn(c, "r_again", cx - bw / 2f, y, cx + bw / 2f, y + bh, "دوباره", Pal.ORANGE, Pal.ORANGE_D, 56f * s)
        y += bh + 26f * s
        btn(c, "r_back", cx - bw / 2f, y, cx + bw / 2f, y + bh, if (mode == 0) "نقشه" else "منوی اصلی", Pal.BLUE, Pal.BLUE_D, 56f * s)
    }

    // ------------------------------------------------------------ دفتر مشق
    private fun drawBook(c: Canvas) {
        drawBackground(c, 1)
        Draw.text(c, "دفتر غلط‌ها", W / 2f, topPad + 60f * s, Draw.fit("دفتر غلط‌ها", 80f * s, 480f * s), Pal.BROWN, 0x33FFFFFF)
        backButton(c)
        gradeChips(c, topPad + 215f * s)

        val gw = Words.grades[grade - 1]
        var seen = 0
        var mastered = 0
        for (w in gw) {
            if (store.correct(w) + store.wrong(w) > 0) seen++
            if (store.mastered(w)) mastered++
        }
        val pct = if (gw.isEmpty()) 0 else mastered * 100 / gw.size
        val cx = W / 2f
        Draw.text(c, "تسلط شما در پایه‌ی ${gradeNames[grade - 1]}: ${fa(pct)}٪", cx, topPad + 340f * s, Draw.fit("تسلط شما در پایه‌ی ${gradeNames[grade - 1]}: ${fa(pct)}٪", 56f * s, W - 140f * s), Pal.BROWN, 0x33FFFFFF)
        val bl = 100f * s
        val br = W - 100f * s
        val by = topPad + 400f * s
        Draw.rect(c, bl, by, br, by + 34f * s, 17f * s, withAlpha(Pal.BROWN, 90))
        if (pct > 0) Draw.rect(c, bl, by, bl + (br - bl) * pct / 100f, by + 34f * s, 17f * s, Pal.GREEN)
        Draw.text(c, "واژه‌های دیده‌شده: ${fa(seen)} از ${fa(gw.size)}", cx, by + 80f * s, 40f * s, Pal.INK, 0)
        Draw.text(c, "پاسخ درست: ${fa(store.totalCorrect)} از ${fa(store.totalAnswered)}", cx, by + 135f * s, 40f * s, Pal.INK, 0)

        val weak = gw.filter { store.wrong(it) > 0 }.sortedByDescending { store.wrong(it) * 2 - store.correct(it) }.take(12)
        val top = by + 215f * s
        if (weak.isEmpty()) {
            Draw.text(c, "هنوز واژه‌ی اشتباهی نداری، آفرین!", cx, top + 60f * s, Draw.fit("هنوز واژه‌ی اشتباهی نداری، آفرین!", 52f * s, W - 140f * s), Pal.GREEN_D, 0)
        } else {
            Draw.text(c, "واژه‌هایی که باید بیشتر مرور کنی", cx, top, Draw.fit("واژه‌هایی که باید بیشتر مرور کنی", 48f * s, W - 140f * s), Pal.RED_D, 0)
        }
        val gap = 16f * s
        val cw = (W - 2f * 80f * s - gap) / 2f
        val chh = 96f * s
        for (i in weak.indices) {
            val w = weak[i]
            val col = i % 2
            val row = i / 2
            val l = W - 80f * s - cw - col * (cw + gap)
            val t = top + 40f * s + row * (chh + gap)
            val bad = store.wrong(w) > store.correct(w)
            Draw.rect(c, l, t, l + cw, t + chh, 24f * s, if (bad) Pal.RED else Pal.GOLD_D)
            Draw.text(c, w, l + cw * 0.64f, t + chh / 2f, Draw.fit(w, 52f * s, cw * 0.5f), Pal.WHITE, 0x33000000)
            Draw.text(c, "${fa(store.wrong(w))} بار", l + cw * 0.17f, t + chh / 2f, 32f * s, Pal.CREAM, 0)
        }
        val rows = (weak.size + 1) / 2
        val bw = 780f * s
        val bt = min(top + 40f * s + rows * (chh + gap) + 24f * s, H - 64f * s - 140f * s)
        btn(c, "weak", W / 2f - bw / 2f, bt, W / 2f + bw / 2f, bt + 140f * s, "تمرین واژه‌های ضعیف", Pal.GREEN, Pal.GREEN_D, 56f * s)
    }

    // ------------------------------------------------------------ درباره / طراح و سازنده
    private fun drawAbout(c: Canvas) {
        drawBackground(c, 0)
        val cx = W / 2f
        Draw.girih(c, cx, H * 0.46f, 640f * s, tAll * 4f, withAlpha(Pal.GOLD, 60), 6f * s)
        Draw.girih(c, cx, H * 0.46f, 500f * s, -tAll * 6f, withAlpha(Pal.TURQ, 60), 5f * s)
        backButton(c)

        val l = 80f * s
        val r = W - 80f * s
        val t = H * 0.17f
        val b = H * 0.75f
        Draw.rect(c, l, t + 14f * s, r, b + 14f * s, 50f * s, withAlpha(black, 90))
        Draw.rect(c, l, t, r, b, 50f * s, withAlpha(Pal.NIGHT1, 235))
        Draw.frame(c, l + 14f * s, t + 14f * s, r - 14f * s, b - 14f * s, 40f * s, Pal.GOLD, 8f * s)

        val h = b - t
        Draw.text(c, "املای من", cx, t + h * 0.10f, Draw.fit("املای من", 120f * s, 800f * s), Pal.GOLD, Pal.ORANGE_D)
        for (k in -2..2) {
            Draw.girih(c, cx + k * 110f * s, t + h * 0.20f, 34f * s, tAll * 30f * (if (k % 2 == 0) 1f else -1f), Pal.GOLD, 3f * s)
        }
        Draw.text(c, "بازی آموزشی املای فارسی", cx, t + h * 0.30f, 54f * s, Pal.WHITE)
        Draw.text(c, "ویژه‌ی دبستان، پایه‌ی اول تا ششم", cx, t + h * 0.37f, 44f * s, Pal.CREAM)

        Draw.line(c, l + 120f * s, t + h * 0.45f, r - 120f * s, t + h * 0.45f, withAlpha(Pal.GOLD, 160), 4f * s)

        Draw.text(c, "طراح و سازنده", cx, t + h * 0.54f, 56f * s, Pal.TURQ)
        val nm = "شاهین شیخ کانلو"
        Draw.text(c, nm, cx, t + h * 0.65f, Draw.fit(nm, 118f * s, 800f * s), Pal.GOLD, Pal.ORANGE_D)

        Draw.line(c, l + 120f * s, t + h * 0.75f, r - 120f * s, t + h * 0.75f, withAlpha(Pal.GOLD, 160), 4f * s)
        Draw.text(c, "ساخته‌شده با عشق برای", cx, t + h * 0.82f, 42f * s, Pal.CREAM, 0)
        Draw.text(c, "یادگیری شاد املای فارسی", cx, t + h * 0.88f, 42f * s, Pal.CREAM, 0)
        Draw.text(c, "نسخه ${fa(1)}.${fa(0)}", cx, t + h * 0.95f - 6f * s, 34f * s, Pal.GRAY, 0)
    }

    // ------------------------------------------------------------ صحنه‌های هر پایه
    private fun drawScene(c: Canvas, kind: Int, hz: Float) {
        when (kind) {
            0 -> sceneGarden(c, hz)
            1 -> sceneSea(c, hz)
            2 -> sceneDesert(c, hz)
            3 -> sceneForest(c, hz)
            4 -> sceneMountain(c, hz)
            else -> scenePalace(c, hz)
        }
    }

    private fun sceneGarden(c: Canvas, hz: Float) {
        val cloud = withAlpha(Pal.WHITE, 215)
        for (i in 0 until 4) {
            val cx = (tAll * 16f * s + i * 340f * s) % (W + 440f * s) - 220f * s
            val cy = hz - 330f * s + (i % 2) * 90f * s
            Draw.oval(c, cx, cy, 120f * s, 40f * s, cloud)
            Draw.oval(c, cx + 70f * s, cy - 24f * s, 85f * s, 38f * s, cloud)
            Draw.oval(c, cx - 70f * s, cy - 14f * s, 75f * s, 32f * s, cloud)
        }
        fillDune(c, hz - 20f * s, 34f, 0.003f, 0.5f, 0xFF4CAF50.toInt())
        fillDune(c, hz + 70f * s, 30f, 0.004f, 2.2f, 0xFF2E8B3D.toInt())
        val fc = intArrayOf(Pal.RED, Pal.GOLD, 0xFFFF7AC8.toInt(), Pal.WHITE, Pal.ORANGE)
        for (i in 0 until 16) {
            val x = ((i * 191 + 37) % 1000) / 1000f * W
            val y = hz + 90f * s + ((i * 73) % 100) / 100f * 150f * s
            val sw = sin(tAll * 1.6f + i) * 5f * s
            Draw.line(c, x, y + 36f * s, x + sw, y, 0xFF1B6B2A.toInt(), 5f * s)
            Draw.circle(c, x + sw, y - 6f * s, 15f * s, fc[i % fc.size])
            Draw.circle(c, x + sw, y - 6f * s, 6f * s, 0xFFFFF1A8.toInt())
        }
        for (i in 0 until 3) {
            val bx = W * (0.25f + 0.25f * i) + sin(tAll * 0.7f + i * 2f) * 160f * s
            val by = hz - 80f * s + sin(tAll * 1.3f + i * 2.5f) * 70f * s
            val wing = 8f + 16f * abs(sin(tAll * 11f + i))
            Draw.oval(c, bx - 12f * s, by, wing * s, 14f * s, fc[(i + 1) % 5])
            Draw.oval(c, bx + 12f * s, by, wing * s, 14f * s, fc[(i + 1) % 5])
        }
    }

    private fun sceneSea(c: Canvas, hz: Float) {
        Draw.circle(c, W * 0.2f, hz - 170f * s, 100f * s, withAlpha(0xFFFFE08A.toInt(), 70))
        Draw.circle(c, W * 0.2f, hz - 170f * s, 70f * s, 0xFFFFE08A.toInt())
        val brown = 0xFF8B5A1B.toInt()
        val bx = (tAll * 40f * s) % (W + 400f * s) - 200f * s
        val by = hz + 10f * s + sin(tAll * 2f) * 8f * s
        Draw.tri(c, bx - 70f * s, by, bx + 70f * s, by, bx + 50f * s, by + 40f * s, brown)
        Draw.tri(c, bx - 70f * s, by, bx + 50f * s, by + 40f * s, bx - 50f * s, by + 40f * s, brown)
        Draw.line(c, bx, by, bx, by - 130f * s, brown, 6f * s)
        Draw.tri(c, bx + 6f * s, by - 125f * s, bx + 6f * s, by - 10f * s, bx + 80f * s, by - 10f * s, Pal.WHITE)
        Draw.tri(c, bx - 6f * s, by - 110f * s, bx - 6f * s, by - 10f * s, bx - 60f * s, by - 10f * s, Pal.CREAM)
        val layers = intArrayOf(0xFF1E88E5.toInt(), 0xFF1565C0.toInt(), 0xFF0D47A1.toInt())
        for (k in 0..2) {
            fillDune(c, hz + 20f * s + k * 46f * s, 12f + 5f * k, 0.006f + 0.001f * k, tAll * (1.1f + 0.4f * k), layers[k])
        }
        for (i in 0 until 8) {
            val x = ((i * 233 + 41) % 1000) / 1000f * W
            val y = hz + 150f * s + ((i * 97) % 100) / 100f * 200f * s
            val ph = (tAll * 0.5f + i * 0.37f) % 1f
            Draw.ring(c, x, y - ph * 120f * s, (6f + 8f * ph) * s, withAlpha(Pal.WHITE, (160 * (1f - ph)).toInt()), 3f * s)
        }
    }

    private fun sceneDesert(c: Canvas, hz: Float) {
        Draw.circle(c, W * 0.78f, hz - 190f * s, 110f * s, withAlpha(0xFFFFD27A.toInt(), 70))
        Draw.circle(c, W * 0.78f, hz - 190f * s, 78f * s, 0xFFFFC857.toInt())
        Draw.tri(c, W * 0.10f, hz + 10f * s, W * 0.28f, hz - 190f * s, W * 0.46f, hz + 10f * s, 0xFFC9964A.toInt())
        Draw.tri(c, W * 0.28f, hz - 190f * s, W * 0.46f, hz + 10f * s, W * 0.28f, hz + 10f * s, 0xFFA97A34.toInt())
        fillDune(c, hz + 10f * s, 36f, 0.0035f, 1f, 0xFFE2B45E.toInt())
        val camX = (tAll * 50f * s) % (W + 500f * s) - 250f * s
        Art.camel(c, camX, duneY(camX, hz + 10f * s, 36f, 0.0035f, 1f) + 8f * s, 0.42f * s, tAll, true, false)
        fillDune(c, hz + 90f * s, 40f, 0.003f, 3f, 0xFFC98F3C.toInt())
        for (i in 0 until 6) {
            val x = ((tAll * (140f + i * 25f) * s) + i * 260f * s) % (W + 300f * s) - 150f * s
            val y = hz + 120f * s + i * 38f * s
            Draw.line(c, x, y, x + 70f * s, y - 6f * s, withAlpha(Pal.WHITE, 50), 4f * s)
        }
    }

    private fun sceneForest(c: Canvas, hz: Float) {
        fillDune(c, hz + 30f * s, 22f, 0.004f, 1f, 0xFF3A2A18.toInt())
        val greens = intArrayOf(0xFF2D5A27.toInt(), 0xFF1B4D20.toInt())
        val autumn = intArrayOf(0xFFB5651D.toInt(), 0xFFD2691E.toInt())
        for (row in 0..1) {
            val n = 7 + row
            val sc = if (row == 0) 0.75f else 1.1f
            for (i in 0 until n) {
                val x = (i + 0.5f + row * 0.3f) * W / n
                val by = hz + 60f * s + row * 90f * s
                val h = 260f * s * sc
                val col = if ((i + row) % 2 == 0) greens[row] else autumn[(i + row) % 2]
                Draw.rect(c, x - 14f * s * sc, by - 40f * s * sc, x + 14f * s * sc, by, 4f * s, 0xFF4A2F18.toInt())
                Draw.tri(c, x - 90f * s * sc, by - 40f * s * sc, x + 90f * s * sc, by - 40f * s * sc, x, by - h * 0.7f, col)
                Draw.tri(c, x - 70f * s * sc, by - h * 0.4f, x + 70f * s * sc, by - h * 0.4f, x, by - h, col)
            }
        }
        val leaf = intArrayOf(0xFFE8751A.toInt(), Pal.GOLD, Pal.RED)
        for (i in 0 until 14) {
            val fx = ((i * 257 + 53) % 1000) / 1000f * W + sin(tAll * 0.9f + i) * 60f * s
            val fy = (tAll * (60f + (i % 4) * 14f) * s + i * 173f * s) % (hz + 360f * s)
            Draw.oval(c, fx, fy, 14f * s, 8f * s, leaf[i % 3])
        }
        for (i in 0 until 8) {
            val fx = ((i * 331 + 17) % 1000) / 1000f * W + sin(tAll * 0.6f + i * 1.7f) * 50f * s
            val fy = hz + 20f * s + ((i * 89) % 100) / 100f * 240f * s + cos(tAll * 0.8f + i) * 30f * s
            val a = (90 + 150 * (0.5f + 0.5f * sin(tAll * 2.3f + i))).toInt()
            Draw.circle(c, fx, fy, 16f * s, withAlpha(0xFFFFF59D.toInt(), a / 3))
            Draw.circle(c, fx, fy, 5f * s, withAlpha(0xFFFFF59D.toInt(), a))
        }
    }

    private fun sceneMountain(c: Canvas, hz: Float) {
        val px = floatArrayOf(0.08f, 0.34f, 0.62f, 0.92f)
        val ph = floatArrayOf(300f, 460f, 380f, 280f)
        for (k in 0..3) {
            val x = W * px[k]
            val h = ph[k] * s
            val bw = 380f * s
            Draw.tri(c, x - bw, hz + 20f * s, x, hz - h, x + bw, hz + 20f * s, 0xFF6573C3.toInt())
            Draw.tri(c, x, hz - h, x + bw, hz + 20f * s, x + bw * 0.1f, hz + 20f * s, 0xFF4B58A6.toInt())
            Draw.tri(c, x - bw * 0.22f, hz - h * 0.78f, x, hz - h, x + bw * 0.22f, hz - h * 0.78f, Pal.WHITE)
        }
        fillDune(c, hz + 60f * s, 26f, 0.005f, 0.7f, 0xFF3949AB.toInt())
        fillDune(c, hz + 130f * s, 24f, 0.004f, 2f, 0xFF283593.toInt())
        for (i in 0 until 26) {
            val x = ((i * 149 + 11) % 1000) / 1000f * W + sin(tAll * 0.8f + i) * 30f * s
            val y = (tAll * (50f + (i % 5) * 14f) * s + i * 97f * s) % H
            Draw.circle(c, x, y, (3f + (i % 3)) * s, withAlpha(Pal.WHITE, 200))
        }
    }

    private fun scenePalace(c: Canvas, hz: Float) {
        Draw.circle(c, W * 0.2f, hz - 260f * s, 110f * s, withAlpha(0xFFFFE9A8.toInt(), 40))
        Draw.circle(c, W * 0.2f, hz - 260f * s, 80f * s, 0xFFFFE9A8.toInt())
        val dark = 0xFF1A1236.toInt()
        val dark2 = 0xFF2E2266.toInt()
        val xs = floatArrayOf(0.14f, 0.50f, 0.86f, 0.32f, 0.68f)
        val ws = floatArrayOf(330f, 440f, 330f, 250f, 250f)
        for (k in 0..4) {
            val base = if (k < 3) hz + 90f * s else hz + 120f * s
            Draw.dome(c, W * xs[k], base, ws[k] * s, if (k < 3) dark2 else 0xFF241A52.toInt(), dark)
        }
        c.drawRect(0f, hz + 90f * s, W, H, bgPaint.apply { shader = null; color = dark })
        for (i in 0 until 9) {
            val lx = ((i * 211 + 17) % 1000) / 1000f * W
            val ly = hz - 40f * s + sin(tAll * 1.1f + i) * 28f * s - (i % 3) * 70f * s
            Draw.circle(c, lx, ly, 26f * s, withAlpha(Pal.GOLD, 50))
            Draw.circle(c, lx, ly, 10f * s, withAlpha(Pal.GOLD, 230))
        }
    }

    // ------------------------------------------------------------ بازی بادکنک‌ها
    private fun randWord(): String {
        val gw = Words.grades[grade - 1]
        val weak = if (rnd.nextInt(100) < 35) gw.filter { store.wrong(it) > 0 } else emptyList()
        val src = if (weak.isNotEmpty()) weak else gw
        return src[rnd.nextInt(src.size)]
    }

    private fun startBalloon() {
        mode = 3
        hearts = 3
        score = 0
        combo = 0
        bestCombo = 0
        correctCount = 0
        coinsEarned = 0
        balTime = 60f
        balElapsed = 0f
        balSpawn = 0.3f
        balloons.clear()
        paused = false
        phase = 0
        endPending = 0
        shake = 0f
        flashRed = 0f
        wrongWords.clear()
        parts.clear()
        ftexts.clear()
        go(Screen.BALLOON)
        snd.play("whoosh")
    }

    private fun spawnBalloon() {
        val w = randWord()
        var ok = rnd.nextInt(100) >= 55
        var shown = w
        if (!ok) {
            val bad = Words.wrongForm(w, grade, rnd, emptyList())
            if (bad == null) ok = true else shown = bad
        }
        val rx = 135f * s
        val x = rx + 20f * s + rnd.nextFloat() * (W - 2f * rx - 40f * s)
        val speed = (170f + rnd.nextFloat() * 70f + balElapsed * 2.2f) * s
        val k = rnd.nextInt(balCols.size)
        balloons.add(Balloon(balId++, shown, w, ok, x, H + 180f * s, speed, balCols[k], balColsD[k], rx, rnd.nextFloat() * 6f))
    }

    private fun balEnd(lose: Boolean) {
        phase = 2
        endPending = if (lose) 2 else 3
        endTimer = 1.2f
        ftexts.add(FText(if (lose) "بادکنک‌ها تمام شدند!" else "تمام شد!", W / 2f, H * 0.3f, 0f, Pal.GOLD, 84f * s))
        snd.play(if (lose) "boom" else "star")
    }

    private fun updateBalloon(dt: Float) {
        if (paused) return
        if (phase == 2) {
            endTimer -= dt
            if (endTimer <= 0f) finishBalloon()
            return
        }
        balElapsed += dt
        balTime -= dt
        balSpawn -= dt
        if (balSpawn <= 0f) {
            spawnBalloon()
            balSpawn = max(0.5f, 1.15f - balElapsed * 0.009f)
        }
        var i = balloons.size - 1
        while (i >= 0) {
            val b = balloons[i]
            b.y -= b.vy * dt
            if (b.y < -190f * s) {
                balloons.removeAt(i)
                if (!b.ok) {
                    store.record(b.real, false)
                    if (!wrongWords.contains(b.real)) wrongWords.add(b.real)
                    hearts--
                    combo = 0
                    snd.play("wrong")
                    shake = 0.7f
                    flashRed = 0.8f
                    ftexts.add(FText("یک غلط رد شد!", W / 2f, H * 0.25f, 0f, Pal.RED, 70f * s))
                    if (hearts <= 0 && phase != 2) balEnd(true)
                }
            }
            i--
        }
        if (balTime <= 0f && phase != 2) balEnd(false)
    }

    private fun balloonTap(id: String) {
        if (phase != 0 || !id.startsWith("bal")) return
        val bid = id.substring(3).toIntOrNull() ?: return
        val b = balloons.firstOrNull { it.id == bid } ?: return
        balloons.remove(b)
        if (!b.ok) {
            combo++
            if (combo > bestCombo) bestCombo = combo
            correctCount++
            val gain = 10 + max(0, combo - 2) * 5
            score += gain
            store.record(b.real, true)
            val cg = if (combo >= 5) 3 else if (combo >= 3) 2 else 1
            store.coins = store.coins + cg
            coinsEarned += cg
            snd.play("hit")
            snd.play("coin")
            burst(b.x, b.y, 16, 1, 800f * s, confettiColors)
            ftexts.add(FText("+${fa(gain)}", b.x, b.y - 70f * s, 0f, Pal.GOLD, 70f * s))
            ftexts.add(FText(b.real, b.x, b.y + 50f * s, 0f, Pal.GREEN, 66f * s))
        } else {
            combo = 0
            hearts--
            store.record(b.real, false)
            if (!wrongWords.contains(b.real)) wrongWords.add(b.real)
            snd.play("wrong")
            shake = 1f
            flashRed = 1f
            vibrate(100)
            burst(b.x, b.y, 10, 0, 500f * s, intArrayOf(Pal.RED))
            ftexts.add(FText("این درست بود!", b.x, b.y, 0f, Pal.RED, 62f * s))
            if (hearts <= 0) balEnd(true)
        }
    }

    private fun finishBalloon() {
        resWin = hearts > 0
        resScore = score
        resCorrect = correctCount
        resCombo = bestCombo
        resWrong = wrongWords.take(3)
        val bonus = correctCount / 3
        store.coins = store.coins + bonus
        coinsEarned += bonus
        resCoins = coinsEarned
        resNewBest = score > store.blitzBest(grade + 10)
        if (resNewBest) store.setBlitzBest(grade + 10, score)
        resBest = store.blitzBest(grade + 10)
        resStars = 0
        snd.play(if (resWin) "win" else "lose")
        go(Screen.RESULT)
    }

    private fun drawBalloon(c: Canvas) {
        drawBackground(c, playTheme[grade - 1], grade - 1, H * 0.6f)
        c.save()
        if (shake > 0f) c.translate((rnd.nextFloat() - 0.5f) * shake * 30f * s, (rnd.nextFloat() - 0.5f) * shake * 30f * s)
        val cx = W / 2f
        btn(c, "pause", 30f * s, hudCy - 52f * s, 134f * s, hudCy + 52f * s + 14f * s, "", Pal.BLUE, Pal.BLUE_D, 10f)
        Draw.rect(c, 82f * s - 17f * s, hudCy - 22f * s, 82f * s - 5f * s, hudCy + 22f * s, 4f * s, Pal.WHITE)
        Draw.rect(c, 82f * s + 5f * s, hudCy - 22f * s, 82f * s + 17f * s, hudCy + 22f * s, 4f * s, Pal.WHITE)
        Draw.rect(c, cx - 190f * s, hudCy - 42f * s, cx + 190f * s, hudCy + 42f * s, 42f * s, withAlpha(black, 110))
        Draw.text(c, "امتیاز: ${fa(score)}", cx, hudCy, 46f * s, Pal.CREAM)
        for (i in 0..2) {
            Draw.heart(c, W - 70f * s - i * 100f * s, hudCy, 86f * s, if (i < hearts) Pal.RED else withAlpha(Pal.WHITE, 60))
        }
        Draw.text(c, "بادکنک‌های غلط", cx, nameCy, 46f * s, Pal.CREAM)
        val bw = 740f * s
        val bh = 30f * s
        Draw.rect(c, cx - bw / 2f, barCy - bh / 2f, cx + bw / 2f, barCy + bh / 2f, bh / 2f, withAlpha(black, 110))
        val frac = (balTime / 60f).coerceIn(0f, 1f)
        if (frac > 0f) {
            Draw.rect(
                c, cx - bw / 2f + 4f * s, barCy - bh / 2f + 4f * s, cx - bw / 2f + 4f * s + (bw - 8f * s) * frac,
                barCy + bh / 2f - 4f * s, bh / 2f, if (frac > 0.25f) Pal.TURQ else Pal.RED
            )
        }
        for (b in balloons) {
            val bx = b.x + sin(tAll * 2f + b.ph) * 14f * s
            val by = b.y
            val ry = b.rx * 1.18f
            Draw.line(c, bx, by + ry, bx + sin(tAll * 3f + b.ph) * 16f * s, by + ry + 110f * s, withAlpha(Pal.WHITE, 170), 3f * s)
            Draw.oval(c, bx, by, b.rx, ry, b.colD)
            Draw.oval(c, bx - 6f * s, by - 8f * s, b.rx - 10f * s, ry - 10f * s, b.col)
            Draw.oval(c, bx - b.rx * 0.4f, by - ry * 0.45f, b.rx * 0.22f, ry * 0.16f, withAlpha(Pal.WHITE, 110))
            Draw.tri(c, bx - 14f * s, by + ry - 6f * s, bx + 14f * s, by + ry - 6f * s, bx, by + ry + 16f * s, b.colD)
            Draw.text(c, b.word, bx, by, Draw.fit(b.word, 70f * s, b.rx * 1.55f), Pal.WHITE, 0x55000000)
            hits.add(Hit("bal${b.id}", bx - b.rx, by - ry, bx + b.rx, by + ry + 20f * s))
        }
        if (balElapsed < 5f) {
            val a = (255f * min(1f, 5f - balElapsed)).toInt()
            val msg = "فقط واژه‌های غلط را بترکان!"
            Draw.text(c, msg, cx, H * 0.40f, Draw.fit(msg, 66f * s, W - 140f * s), withAlpha(Pal.GOLD, a), withAlpha(black, a / 2))
        }
        c.restore()
        if (paused) drawPause(c)
    }

    // ------------------------------------------------------------ واژه‌یاب
    private fun wsPlace(word: String): Boolean {
        val len = word.length
        for (attempt in 0 until 80) {
            val horiz = rnd.nextBoolean()
            val r0: Int
            val c0: Int
            if (horiz) {
                r0 = rnd.nextInt(wsCols)
                c0 = len - 1 + rnd.nextInt(wsCols - len + 1)
            } else {
                r0 = rnd.nextInt(wsCols - len + 1)
                c0 = rnd.nextInt(wsCols)
            }
            var fits = true
            for (k in 0 until len) {
                val r = if (horiz) r0 else r0 + k
                val cc = if (horiz) c0 - k else c0
                val g = wsGrid[r * wsCols + cc]
                if (g != ' ' && g != word[k]) {
                    fits = false
                    break
                }
            }
            if (!fits) continue
            for (k in 0 until len) {
                val r = if (horiz) r0 else r0 + k
                val cc = if (horiz) c0 - k else c0
                wsGrid[r * wsCols + cc] = word[k]
            }
            return true
        }
        return false
    }

    private fun startWS() {
        java.util.Arrays.fill(wsGrid, ' ')
        java.util.Arrays.fill(wsColor, 0)
        java.util.Arrays.fill(wsFound, false)
        wsWords.clear()
        wsDecoys.clear()
        wsStart = -1
        wsMistakes = 0
        wsDone = false
        wsDoneT = 0f
        val pool = Words.grades[grade - 1].filter { it.length in 3..5 && !it.contains('‌') }.shuffled(rnd)
        for (w in pool) {
            if (wsWords.size >= 4) break
            if (wsPlace(w)) wsWords.add(w)
        }
        for (k in 0 until 2) {
            if (k < wsWords.size) {
                val bad = Words.wrongForm(wsWords[k], grade, rnd, emptyList())
                if (bad != null && wsPlace(bad)) wsDecoys.add(bad)
            }
        }
        val fill = "ابپتجدرزسشطعفقکگلمنوهی"
        for (i in 0 until wsGrid.size) if (wsGrid[i] == ' ') wsGrid[i] = fill[rnd.nextInt(fill.length)]
        ftexts.clear()
        parts.clear()
        go(Screen.WSEARCH)
        snd.play("whoosh")
    }

    private fun wsTap(id: String) {
        if (wsDone) return
        val i = id.substring(2).toIntOrNull() ?: return
        if (wsStart < 0) {
            wsStart = i
            return
        }
        if (wsStart == i) {
            wsStart = -1
            return
        }
        val a = wsStart
        wsStart = -1
        val ar = a / wsCols
        val ac = a % wsCols
        val br = i / wsCols
        val bc = i % wsCols
        if (ar != br && ac != bc) {
            snd.play("wrong")
            ftexts.add(FText("باید در یک خط باشد", W / 2f, H * 0.27f, 0f, Pal.RED, 60f * s))
            return
        }
        val dr = Integer.signum(br - ar)
        val dc = Integer.signum(bc - ac)
        val cells = ArrayList<Int>()
        val sb = StringBuilder()
        var r = ar
        var cc = ac
        while (true) {
            val idx = r * wsCols + cc
            cells.add(idx)
            sb.append(wsGrid[idx])
            if (r == br && cc == bc) break
            r += dr
            cc += dc
        }
        val str = sb.toString()
        val rev = sb.reverse().toString()
        for (k in wsWords.indices) {
            if (!wsFound[k] && (str == wsWords[k] || rev == wsWords[k])) {
                wsFound[k] = true
                val col = wsPalette[k % wsPalette.size]
                for (idx in cells) wsColor[idx] = col
                store.record(wsWords[k], true)
                snd.play("correct")
                snd.play("coin")
                val mid = cells[cells.size / 2]
                burst(W / 2f, H * 0.5f, 20, 1, 800f * s, confettiColors)
                ftexts.add(FText("آفرین!", W / 2f, H * 0.27f, 0f, Pal.GREEN, 84f * s))
                if (mid >= 0 && wsWords.indices.all { wsFound[it] }) {
                    wsDone = true
                    wsDoneT = 0f
                    wsReward = max(5, 20 - wsMistakes * 3)
                    store.coins = store.coins + wsReward
                    snd.play("win")
                }
                return
            }
        }
        if (wsDecoys.contains(str) || wsDecoys.contains(rev)) {
            wsMistakes++
            snd.play("wrong")
            shake = 1f
            vibrate(100)
            ftexts.add(FText("این غلط نوشته شده!", W / 2f, H * 0.27f, 0f, Pal.RED, 68f * s))
            return
        }
        snd.play("wrong")
        ftexts.add(FText("این واژه نیست", W / 2f, H * 0.27f, 0f, Pal.ORANGE, 60f * s))
    }

    private fun drawWS(c: Canvas) {
        drawBackground(c, playTheme[grade - 1])
        c.save()
        if (shake > 0f) c.translate((rnd.nextFloat() - 0.5f) * shake * 24f * s, (rnd.nextFloat() - 0.5f) * shake * 24f * s)
        val cx = W / 2f
        Draw.text(c, "واژه‌یاب", cx, topPad + 60f * s, Draw.fit("واژه‌یاب", 80f * s, 480f * s), Pal.GOLD, Pal.ORANGE_D)
        backButton(c)
        coinPill(c, W - 30f * s, topPad + 60f * s)
        val hint = "دو سرِ واژه‌ی درست‌نوشته را بزن"
        Draw.text(c, hint, cx, topPad + 190f * s, Draw.fit(hint, 44f * s, W - 140f * s), Pal.CREAM, 0)

        val gap = 14f * s
        val cw = (W - 2f * 80f * s - gap) / 2f
        val ch = 96f * s
        val listTop = topPad + 250f * s
        for (k in wsWords.indices) {
            val col = k % 2
            val row = k / 2
            val l = W - 80f * s - cw - col * (cw + gap)
            val t = listTop + row * (ch + gap)
            val done = wsFound[k]
            Draw.rect(c, l, t, l + cw, t + ch, 26f * s, if (done) Pal.GREEN_D else withAlpha(black, 120))
            Draw.text(c, wsWords[k], l + cw / 2f, t + ch / 2f, Draw.fit(wsWords[k], 58f * s, cw * 0.8f), if (done) Pal.CREAM else Pal.WHITE, 0)
            if (done) {
                Draw.line(c, l + 34f * s, t + ch / 2f, l + 54f * s, t + ch / 2f + 18f * s, Pal.WHITE, 8f * s)
                Draw.line(c, l + 54f * s, t + ch / 2f + 18f * s, l + 86f * s, t + ch / 2f - 18f * s, Pal.WHITE, 8f * s)
            }
        }
        val top = listTop + 2f * (ch + gap) + 30f * s
        val cg = 8f * s
        val cell = min(118f * s, (H - top - 80f * s - 6f * cg) / wsCols)
        val gw = wsCols * cell + (wsCols - 1) * cg
        val left = (W - gw) / 2f
        for (idx in 0 until wsGrid.size) {
            val r = idx / wsCols
            val cc = idx % wsCols
            val l = left + cc * (cell + cg)
            val t = top + r * (cell + cg)
            val found = wsColor[idx] != 0
            val sel = idx == wsStart
            val face = if (found) wsColor[idx] else if (sel) Pal.GOLD else Pal.CREAM
            val dy = if (pressedId == "wc$idx") 5f * s else 0f
            Draw.rect(c, l, t + 7f * s, l + cell, t + cell, 20f * s, if (found) withAlpha(black, 90) else Pal.SAND_D)
            Draw.rect(c, l, t + dy, l + cell, t + cell - 7f * s + dy, 20f * s, face)
            Draw.text(c, wsGrid[idx].toString(), l + cell / 2f, t + (cell - 7f * s) / 2f + dy, cell * 0.6f, if (found) Pal.WHITE else Pal.INK, 0)
            if (!wsDone) hits.add(Hit("wc$idx", l, t, l + cell, t + cell))
        }
        c.restore()
        if (wsDone && wsDoneT > 0.8f) {
            hits.clear()
            c.drawColor(withAlpha(black, 170))
            Draw.girih(c, cx, H * 0.3f, 380f * s, tAll * 8f, withAlpha(Pal.GOLD, 80), 5f * s)
            Draw.text(c, "آفرین!", cx, H * 0.27f, 140f * s, Pal.GOLD, Pal.ORANGE_D)
            val msg = "${fa(wsReward)} سکه گرفتی"
            Draw.text(c, msg, cx, H * 0.38f, 64f * s, Pal.CREAM)
            val bw = 760f * s
            val bh = 130f * s
            btn(c, "ws_next", cx - bw / 2f, H * 0.48f, cx + bw / 2f, H * 0.48f + bh, "جدول بعدی", Pal.GREEN, Pal.GREEN_D, 58f * s)
            btn(c, "ws_home", cx - bw / 2f, H * 0.48f + bh + 30f * s, cx + bw / 2f, H * 0.48f + 2f * bh + 30f * s, "منوی اصلی", Pal.BLUE, Pal.BLUE_D, 56f * s)
        }
    }

    // ------------------------------------------------------------ ذرات و نوشته‌های شناور
    private fun drawFx(c: Canvas) {
        for (p in parts) {
            val k = p.age / p.life
            val a = (255f * (if (k < 0.7f) 1f else (1f - k) / 0.3f)).toInt()
            val col = withAlpha(p.color, a)
            when (p.kind) {
                0 -> Draw.circle(c, p.x, p.y, p.size * 0.5f * (1f - k * 0.5f), col)
                1 -> Draw.star(c, p.x, p.y, p.size, p.size * 0.45f, 5, p.rot, col)
                2 -> {
                    c.save()
                    c.translate(p.x, p.y)
                    c.rotate(p.rot)
                    Draw.rect(c, -p.size / 2f, -p.size / 4f, p.size / 2f, p.size / 4f, 2f * s, col)
                    c.restore()
                }
                else -> {
                    val sq = max(0.15f, abs(cos(p.rot * 0.05f)))
                    Draw.oval(c, p.x, p.y, p.size * 0.6f * sq, p.size * 0.6f, withAlpha(Pal.GOLD_D, a))
                    Draw.oval(c, p.x, p.y, p.size * 0.42f * sq, p.size * 0.42f, col)
                }
            }
        }
        for (f in ftexts) {
            val k = f.age / 1.2f
            val a = (255f * (if (k < 0.6f) 1f else (1f - k) / 0.4f)).toInt()
            val pop = 1f + 0.25f * max(0f, 1f - f.age / 0.2f)
            Draw.text(c, f.text, f.x, f.y, f.size * pop, withAlpha(f.color, a), withAlpha(black, a / 2))
        }
    }
}
